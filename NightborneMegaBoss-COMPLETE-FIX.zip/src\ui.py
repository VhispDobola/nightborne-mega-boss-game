import pygame
from powerups import PowerUpType

class UI:
    def __init__(self, game):
        self.game = game
        self.font = pygame.font.Font(None, 24)
        self.small_font = pygame.font.Font(None, 18)
        self.large_font = pygame.font.Font(None, 32)
        
        # UI colors
        self.hp_bar_color = (200, 50, 50)
        self.hp_bg_color = (50, 50, 50)
        self.xp_bar_color = (50, 200, 50)
        self.xp_bg_color = (30, 30, 30)
        self.text_color = (255, 255, 255)
        
        # UI positions (will be updated in draw to match screen size)
        self.hp_bar_pos = (20, 20)
        self.hp_bar_size = (300, 25)
        self.xp_bar_pos = (20, 680)
        self.xp_bar_size = (400, 20)
        
    def draw(self):
        """Draw all UI elements"""
        self.draw_hp_bar()
        self.draw_xp_bar()
        self.draw_stats()
        self.draw_timer()
        self.draw_combo()
        self.draw_wave_info()
        self.draw_power_up_indicators()
        self.draw_active_ability_indicators()
        
    def draw_hp_bar(self):
        """Draw HP bar at top-left"""
        # Update position based on screen size
        x, y = 20, 20
        width, height = 300, 25
        
        # Draw background
        pygame.draw.rect(self.game.screen, self.hp_bg_color, (x, y, width, height))
        pygame.draw.rect(self.game.screen, (100, 100, 100), (x, y, width, height), 2)
        
        # Draw HP fill
        player = self.game.player
        hp_percentage = player.hp / player.max_hp
        hp_width = int(width * hp_percentage)
        
        # Change color based on HP percentage
        if hp_percentage > 0.6:
            color = (50, 200, 50)
        elif hp_percentage > 0.3:
            color = (200, 200, 50)
        else:
            color = (200, 50, 50)
            
        pygame.draw.rect(self.game.screen, color, (x, y, hp_width, height))
        
        # Draw HP text
        hp_text = f"HP: {int(player.hp)}/{int(player.max_hp)}"
        text_surface = self.font.render(hp_text, True, self.text_color)
        self.game.screen.blit(text_surface, (x + 5, y + 3))
        
    def draw_xp_bar(self):
        """Draw XP bar at bottom"""
        # Update position based on screen size
        x, y = 20, self.game.screen_height - 50
        width, height = 400, 20
        
        # Draw background
        pygame.draw.rect(self.game.screen, self.xp_bg_color, (x, y, width, height))
        pygame.draw.rect(self.game.screen, (80, 80, 80), (x, y, width, height), 2)
        
        # Draw XP fill
        player = self.game.player
        xp_percentage = player.xp / player.xp_to_next_level
        xp_width = int(width * xp_percentage)
        
        pygame.draw.rect(self.game.screen, self.xp_bar_color, (x, y, xp_width, height))
        
        # Draw XP text
        xp_text = f"Level {player.level} - XP: {int(player.xp)}/{int(player.xp_to_next_level)}"
        text_surface = self.font.render(xp_text, True, self.text_color)
        self.game.screen.blit(text_surface, (x + 5, y + 2))
        
    def draw_stats(self):
        """Draw player stats in top-right"""
        player = self.game.player
        x = self.game.screen_width - 250
        y = 20
        line_height = 25
        
        stats = [
            f"Damage: {player.damage}",
            f"Fire Rate: {player.weapon.fire_rate:.1f}/s",
            f"Speed: {player.speed}",
            f"Projectiles: {player.weapon.projectile_count}",
            f"Pickup: {player.pickup_range}",
            f"Weapon: {player.weapon.weapon_type.value.title()}",
            f"Weapon Level: {getattr(player, 'weapon_level', 1)}"
        ]
        
        # Draw semi-transparent background
        bg_rect = pygame.Rect(x - 10, y - 10, 240, len(stats) * line_height + 20)
        bg_surface = pygame.Surface((bg_rect.width, bg_rect.height), pygame.SRCALPHA)
        bg_surface.fill((0, 0, 0, 150))
        self.game.screen.blit(bg_surface, bg_rect)
        
        # Draw border
        pygame.draw.rect(self.game.screen, (100, 100, 100), bg_rect, 2)
        
        # Draw stats text
        for i, stat in enumerate(stats):
            text_surface = self.small_font.render(stat, True, self.text_color)
            self.game.screen.blit(text_surface, (x, y + i * line_height))
            
    def draw_timer(self):
        """Draw game timer and survival info"""
        # Draw time survived
        time_survived = int(self.game.game_time)
        minutes = time_survived // 60
        seconds = time_survived % 60
        time_text = f"Time: {minutes:02d}:{seconds:02d}"
        
        # Draw target time
        target_time = int(self.game.survival_time)
        target_minutes = target_time // 60
        target_seconds = target_time % 60
        target_text = f"Target: {target_minutes:02d}:{target_seconds:02d}"
        
        # Position at top-center
        x = 640
        y = 20
        
        # Draw time text
        time_surface = self.large_font.render(time_text, True, self.text_color)
        time_rect = time_surface.get_rect(center=(x, y))
        self.game.screen.blit(time_surface, time_rect)
        
        # Draw target text
        target_surface = self.small_font.render(target_text, True, (150, 150, 150))
        target_rect = target_surface.get_rect(center=(x, y + 30))
        self.game.screen.blit(target_surface, target_rect)
        
        # Draw progress bar towards victory
        progress = min(time_survived / target_time, 1.0)
        bar_width = 200
        bar_height = 8
        bar_x = x - bar_width // 2
        bar_y = y + 45
        
        # Background
        pygame.draw.rect(self.game.screen, (50, 50, 50), (bar_x, bar_y, bar_width, bar_height))
        # Progress
        pygame.draw.rect(self.game.screen, (100, 150, 200), (bar_x, bar_y, int(bar_width * progress), bar_height))
        # Border
        pygame.draw.rect(self.game.screen, (100, 100, 100), (bar_x, bar_y, bar_width, bar_height), 1)
        
    def draw_combo(self):
        """Draw combo counter"""
        if self.game.combo_count > 1:
            # Combo text
            combo_text = f"COMBO x{self.game.combo_count}"
            
            # Color based on combo level
            if self.game.combo_count < 5:
                color = (255, 255, 0)
            elif self.game.combo_count < 10:
                color = (255, 200, 0)
            elif self.game.combo_count < 20:
                color = (255, 100, 255)
            else:
                color = (255, 0, 255)
            
            # Draw combo text
            font = pygame.font.Font(None, 32)
            text_surface = font.render(combo_text, True, color)
            text_rect = text_surface.get_rect(center=(640, 100))
            
            # Draw background
            bg_rect = text_rect.inflate(20, 10)
            bg_surface = pygame.Surface((bg_rect.width, bg_rect.height), pygame.SRCALPHA)
            bg_surface.fill((0, 0, 0, 150))
            self.game.screen.blit(bg_surface, bg_rect)
            
            # Draw text
            self.game.screen.blit(text_surface, text_rect)
            
            # Draw combo timer bar
            if self.game.combo_timer > 0:
                bar_width = 100
                bar_height = 4
                bar_x = 640 - bar_width // 2
                bar_y = text_rect.bottom + 5
                
                # Background
                pygame.draw.rect(self.game.screen, (50, 50, 50), (bar_x, bar_y, bar_width, bar_height))
                
                # Timer fill
                timer_percentage = self.game.combo_timer / 2.0  # 2 seconds max
                fill_width = int(bar_width * timer_percentage)
                pygame.draw.rect(self.game.screen, color, (bar_x, bar_y, fill_width, bar_height))
    
    def draw_wave_info(self):
        """Draw wave information"""
        wave_info = self.game.wave_manager.get_wave_info()
        
        # Position at top center
        x = self.game.screen_width // 2
        y = 60
        
        # Draw wave info
        font = pygame.font.Font(None, 28)
        text_surface = font.render(wave_info, True, (255, 255, 255))
        text_rect = text_surface.get_rect(center=(x, y))
        
        # Draw background
        bg_rect = text_rect.inflate(20, 10)
        bg_surface = pygame.Surface((bg_rect.width, bg_rect.height), pygame.SRCALPHA)
        bg_surface.fill((0, 0, 0, 180))
        self.game.screen.blit(bg_surface, bg_rect)
        
        # Draw text
        self.game.screen.blit(text_surface, text_rect)
        
        # Draw wave indicator for boss waves
        if self.game.wave_manager.is_boss_wave():
            boss_text = "⚠ BOSS WAVE ⚠"
            boss_color = (255, 0, 0)
            boss_font = pygame.font.Font(None, 24)
            boss_surface = boss_font.render(boss_text, True, boss_color)
            boss_rect = boss_surface.get_rect(center=(x, y + 25))
            self.game.screen.blit(boss_surface, boss_rect)
    
    def draw_power_up_indicators(self):
        """Draw active power-up indicators"""
        player = self.game.player
        x_offset = 20
        y_offset = 55  # Below HP bar
        icon_size = 20
        spacing = 25
        
        # Draw shield indicator
        if hasattr(player, 'shield_active') and player.shield_active:
            # Shield icon (diamond shape)
            shield_x = x_offset
            shield_y = y_offset
            
            # Draw shield background
            pygame.draw.rect(self.game.screen, (0, 100, 100), 
                           (shield_x - 2, shield_y - 2, icon_size + 4, icon_size + 4))
            
            # Draw shield diamond
            points = [
                (shield_x + icon_size // 2, shield_y),  # Top
                (shield_x + icon_size, shield_y + icon_size // 2),  # Right
                (shield_x + icon_size // 2, shield_y + icon_size),  # Bottom
                (shield_x, shield_y + icon_size // 2)  # Left
            ]
            pygame.draw.polygon(self.game.screen, (0, 255, 200), points)
            pygame.draw.polygon(self.game.screen, (150, 255, 220), points, 2)
            
            # Draw time remaining
            if PowerUpType.SHIELD in player.power_up_effects:
                duration = player.power_up_effects[PowerUpType.SHIELD][0]
                time_text = self.small_font.render(f"{duration:.1f}s", True, (0, 255, 200))
                self.game.screen.blit(time_text, (shield_x + icon_size + 5, shield_y))
        
        # Draw other power-up indicators
        x_offset += spacing + 60  # Move to the right for other indicators
        
        # Multishot indicator
        if PowerUpType.MULTI_SHOT in player.power_up_effects:
            multishot_x = x_offset
            multishot_y = y_offset
            
            # Draw multishot icon (multiple arrows)
            for i in range(3):
                arrow_x = multishot_x + i * 6
                pygame.draw.line(self.game.screen, (255, 200, 0), 
                               (arrow_x, multishot_y + icon_size), 
                               (arrow_x + 4, multishot_y + icon_size - 8), 2)
            
            # Draw time remaining
            duration = player.power_up_effects[PowerUpType.MULTI_SHOT][0]
            time_text = self.small_font.render(f"{duration:.1f}s", True, (255, 200, 0))
            self.game.screen.blit(time_text, (multishot_x + icon_size, multishot_y))
            
            x_offset += spacing
        
        # Damage boost indicator
        if PowerUpType.DAMAGE_BOOST in player.power_up_effects:
            damage_x = x_offset
            damage_y = y_offset
            
            # Draw damage icon (sword/explosion)
            pygame.draw.circle(self.game.screen, (255, 100, 0), 
                             (damage_x + icon_size // 2, damage_y + icon_size // 2), icon_size // 2)
            pygame.draw.circle(self.game.screen, (255, 150, 50), 
                             (damage_x + icon_size // 2, damage_y + icon_size // 2), icon_size // 2, 2)
            
            # Draw time remaining
            duration = player.power_up_effects[PowerUpType.DAMAGE_BOOST][0]
            time_text = self.small_font.render(f"{duration:.1f}s", True, (255, 100, 0))
            self.game.screen.blit(time_text, (damage_x + icon_size, damage_y))
            
            x_offset += spacing
        
        # Speed boost indicator
        if PowerUpType.SPEED_BOOST in player.power_up_effects:
            speed_x = x_offset
            speed_y = y_offset
            
            # Draw speed icon (lightning bolt)
            pygame.draw.lines(self.game.screen, (100, 200, 255), False, [
                (speed_x + 6, speed_y), (speed_x + 10, speed_y + icon_size // 2),
                (speed_x + 14, speed_y + icon_size // 2), (speed_x + 10, speed_y + icon_size),
                (speed_x + 14, speed_y + icon_size)
            ], 3)
            
            # Draw time remaining
            duration = self.game.player.power_up_effects[PowerUpType.SPEED_BOOST][0]
            time_text = self.small_font.render(f"{duration:.1f}s", True, (100, 200, 255))
            self.game.screen.blit(time_text, (speed_x + icon_size, speed_y))

    def draw_active_ability_indicators(self):
        """Draw active ability indicators and cooldowns"""
        player = self.game.player
        if not hasattr(player, 'active_abilities') or not player.active_abilities:
            return
        
        # Position at bottom-right
        x_start = self.game.screen_width - 200
        y_start = self.game.screen_height - 100
        icon_size = 30
        spacing = 35
        
        ability_info = {
            'blast_wave': {'key': 'SPACE', 'color': (100, 200, 255), 'symbol': '◈'},
            'time_slow': {'key': 'SHIFT', 'color': (200, 100, 255), 'symbol': '◉'},
            'shield_burst': {'key': 'F', 'color': (0, 255, 200), 'symbol': '◆'},
            'teleport': {'key': 'E', 'color': (255, 255, 100), 'symbol': '✦'},
            'meteor_strike': {'key': 'Q', 'color': (255, 100, 0), 'symbol': '★'}
        }
        
        for i, ability in enumerate(player.active_abilities):
            if ability not in ability_info:
                continue
                
            info = ability_info[ability]
            x = x_start
            y = y_start - (i * spacing)
            
            # Check if on cooldown
            is_on_cooldown = ability in player.ability_cooldowns
            cooldown_remaining = player.ability_cooldowns.get(ability, 0)
            
            # Draw ability background
            bg_color = (50, 50, 50) if is_on_cooldown else info['color']
            pygame.draw.rect(self.game.screen, bg_color, (x - 2, y - 2, icon_size + 4, icon_size + 4), border_radius=5)
            
            # Draw ability symbol
            symbol_color = (100, 100, 100) if is_on_cooldown else (255, 255, 255)
            font = pygame.font.Font(None, 20)
            symbol_text = font.render(info['symbol'], True, symbol_color)
            symbol_rect = symbol_text.get_rect(center=(x + icon_size // 2, y + icon_size // 2))
            self.game.screen.blit(symbol_text, symbol_rect)
            
            # Draw key binding
            key_text = self.small_font.render(info['key'], True, (200, 200, 200))
            self.game.screen.blit(key_text, (x + icon_size + 5, y + 5))
            
            # Draw cooldown if active
            if is_on_cooldown:
                cooldown_text = self.small_font.render(f"{cooldown_remaining:.1f}s", True, (255, 100, 100))
                self.game.screen.blit(cooldown_text, (x + icon_size + 5, y + 18))

class DamageNumber:
    """Floating damage number for visual feedback"""
    def __init__(self, pos, damage, color=(255, 255, 0)):
        self.pos = pygame.Vector2(pos)
        self.damage = damage
        self.color = color
        self.lifetime = 1.0
        self.age = 0
        self.vel = pygame.Vector2(0, -50)  # Float upward
        
    def update(self, dt):
        self.age += dt
        self.pos += self.vel * dt
        return self.age < self.lifetime
        
    def draw(self, screen, font):
        alpha = 1.0 - (self.age / self.lifetime)
        color = (*self.color, int(255 * alpha))
        
        text = font.render(str(int(self.damage)), True, self.color)
        text_rect = text.get_rect(center=self.pos)
        screen.blit(text, text_rect)

class DamageNumberManager:
    """Manages floating damage numbers"""
    def __init__(self):
        self.damage_numbers = []
        self.font = pygame.font.Font(None, 20)
        
    def add_damage_number(self, pos, damage, color=(255, 255, 0)):
        """Add a new damage number"""
        self.damage_numbers.append(DamageNumber(pos, damage, color))
        
    def update(self, dt):
        """Update all damage numbers"""
        self.damage_numbers = [dn for dn in self.damage_numbers if dn.update(dt)]
        
    def draw(self, screen):
        """Draw all damage numbers"""
        for damage_number in self.damage_numbers:
            damage_number.draw(screen, self.font)
