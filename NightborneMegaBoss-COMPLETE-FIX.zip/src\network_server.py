import socket
import threading
import json
import time
from typing import Optional, Dict, Any, Callable
import pygame

class NetworkServer:
    """Server for hosting multiplayer games over network"""
    
    def __init__(self, host='localhost', port=5555, max_players=4):
        self.host = host
        self.port = port
        self.max_players = max_players
        
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        
        self.clients: Dict[int, socket.socket] = {}  # client_id -> socket
        self.client_data: Dict[int, Dict] = {}  # client_id -> player data
        self.next_client_id = 1
        
        self.running = False
        self.game_state = "lobby"  # lobby, playing, game_over
        self.game_data = {}  # Shared game state
        
        # Network protocol
        self.message_types = {
            'join': 'join',
            'leave': 'leave', 
            'update': 'update',
            'game_state': 'game_state',
            'chat': 'chat',
            'start_game': 'start_game'
        }
    
    def start(self):
        """Start the server"""
        try:
            # Bind to all interfaces for LAN play
            bind_host = '0.0.0.0'  # Allow connections from any IP
            self.server_socket.bind((bind_host, self.port))
            self.server_socket.listen(self.max_players)
            self.running = True
            
            print(f"Server started on {bind_host}:{self.port} (accepting all connections)")
            print(f"Local IP for players: {socket.gethostbyname(socket.gethostname())}:{self.port}")
            
            # Start accepting connections
            accept_thread = threading.Thread(target=self.accept_connections)
            accept_thread.daemon = True
            accept_thread.start()
            
            return True
        except Exception as e:
            print(f"Failed to start server: {e}")
            return False
    
    def accept_connections(self):
        """Accept incoming client connections"""
        while self.running:
            try:
                client_socket, address = self.server_socket.accept()
                
                if len(self.clients) >= self.max_players:
                    # Server full
                    self.send_message(client_socket, {
                        'type': 'server_full',
                        'message': 'Server is full'
                    })
                    client_socket.close()
                    continue
                
                # Assign client ID
                client_id = self.next_client_id
                self.next_client_id += 1
                
                # Store client
                self.clients[client_id] = client_socket
                self.client_data[client_id] = {
                    'id': client_id,
                    'address': address,
                    'joined_time': time.time(),
                    'player_data': {
                        'pos': [400, 300],
                        'hp': 100,
                        'color': self.get_player_color(client_id),
                        'active': True
                    }
                }
                
                print(f"Client {client_id} connected from {address}")
                
                # Send welcome message with client ID
                color = self.get_player_color(client_id)
                self.send_message(client_socket, {
                    'type': 'welcome',
                    'client_id': client_id,
                    'player_color': color  # Send as RGB tuple
                })
                
                # Broadcast new player to all clients
                player_data = self.client_data[client_id]['player_data'].copy()
                # Ensure color is RGB tuple, not object
                if 'color' in player_data:
                    player_data['color'] = self.get_player_color(client_id)
                
                self.broadcast({
                    'type': 'player_joined',
                    'client_id': client_id,
                    'player_data': player_data
                }, exclude_client=client_id)
                
                # Send current game state to new client
                self.send_game_state(client_socket)
                
                # Start client handler thread
                client_thread = threading.Thread(target=self.handle_client, args=(client_id,))
                client_thread.daemon = True
                client_thread.start()
                
            except Exception as e:
                if self.running:
                    print(f"Error accepting connection: {e}")
    
    def handle_client(self, client_id):
        """Handle messages from a specific client"""
        client_socket = self.clients[client_id]
        address = self.client_data[client_id]['address']  # Get client address
        
        while self.running and client_id in self.clients:
            try:
                data = client_socket.recv(4096)
                if not data:
                    break
                
                try:
                    # Check if it's an HTTP request (browser trying to access)
                    if data.startswith(b'GET') or data.startswith(b'POST') or data.startswith(b'HTTP'):
                        print(f"HTTP request detected from {address} - this is not a web server!")
                        print("Players must run the game and use 'Join Game' option")
                        # Send a simple HTTP response
                        http_response = "HTTP/1.1 400 Bad Request\r\n"
                        http_response += "Content-Type: text/plain\r\n"
                        http_response += "\r\n"
                        http_response += "This is a game server, not a web server.\r\n"
                        http_response += "Open the game and use 'Join Game' option to connect.\r\n"
                        client_socket.send(http_response.encode('utf-8'))
                        break
                    try:
                        message = json.loads(data.decode('utf-8'))
                        self.process_message(client_id, message)
                    except json.JSONDecodeError as e:
                        print(f"JSON decode error from client {client_id}: {e}")
                        print(f"Raw data: {data}")
                        break
                except Exception as e:
                    print(f"Error handling client {client_id}: {e}")
                    break
                
            except Exception as e:
                print(f"Error handling client {client_id}: {e}")
                break
        
        # Client disconnected
        self.remove_client(client_id)
    
    def process_message(self, client_id, message):
        """Process incoming message from client"""
        msg_type = message.get('type')
        
        if msg_type == 'update':
            # Update player data
            if 'player_data' in message:
                self.client_data[client_id]['player_data'].update(message['player_data'])
                
                # Broadcast update to other clients
                self.broadcast({
                    'type': 'player_update',
                    'client_id': client_id,
                    'player_data': message['player_data']
                }, exclude_client=client_id)
        
        elif msg_type == 'start_game':
            if self.game_state == "lobby":
                self.game_state = "playing"
                self.broadcast({
                    'type': 'game_started',
                    'game_state': self.game_state
                })
        
        elif msg_type == 'chat':
            # Broadcast chat message
            self.broadcast({
                'type': 'chat',
                'client_id': client_id,
                'message': message.get('message', '')
            })
    
    def send_message(self, client_socket, message):
        """Send message to specific client"""
        try:
            # Convert message to simple dict without complex objects
            simple_message = {}
            for key, value in message.items():
                if isinstance(value, (str, int, float, bool, list, dict, type(None))):
                    simple_message[key] = value
                else:
                    simple_message[key] = str(value)
            
            data = json.dumps(simple_message).encode('utf-8')
            client_socket.send(data)
        except Exception as e:
            print(f"Error sending message: {e}")
    
    def broadcast(self, message, exclude_client=None):
        """Send message to all connected clients"""
        disconnected_clients = []
        
        for client_id, client_socket in self.clients.items():
            if exclude_client and client_id == exclude_client:
                continue
            
            try:
                data = json.dumps(message).encode('utf-8')
                client_socket.send(data)
            except Exception as e:
                print(f"Error broadcasting to client {client_id}: {e}")
                disconnected_clients.append(client_id)
        
        # Remove disconnected clients
        for client_id in disconnected_clients:
            self.remove_client(client_id)
    
    def send_game_state(self, client_socket=None):
        """Send current game state to client(s)"""
        state_message = {
            'type': 'game_state',
            'game_state': self.game_state,
            'players': {cid: data['player_data'] for cid, data in self.client_data.items()},
            'server_info': {
                'current_players': len(self.clients),
                'max_players': self.max_players
            }
        }
        
        if client_socket:
            self.send_message(client_socket, state_message)
        else:
            self.broadcast(state_message)
    
    def remove_client(self, client_id):
        """Remove client from server"""
        if client_id in self.clients:
            try:
                self.clients[client_id].close()
            except:
                pass
            
            del self.clients[client_id]
            
            if client_id in self.client_data:
                del self.client_data[client_id]
            
            print(f"Client {client_id} disconnected")
            
            # Broadcast player left
            self.broadcast({
                'type': 'player_left',
                'client_id': client_id
            })
    
    def get_player_color(self, client_id):
        """Get color for player based on ID"""
        colors = [
            (0, 200, 255),    # Blue
            (0, 255, 100),    # Green  
            (255, 100, 100),  # Red
            (255, 255, 100)   # Yellow
        ]
        return colors[(client_id - 1) % len(colors)]
    
    def get_connected_players(self):
        """Get list of connected players"""
        return [
            {
                'id': client_id,
                'player_data': data['player_data']
            }
            for client_id, data in self.client_data.items()
        ]
    
    def stop(self):
        """Stop the server"""
        self.running = False
        
        # Close all client connections
        for client_socket in self.clients.values():
            try:
                client_socket.close()
            except:
                pass
        
        # Close server socket
        try:
            self.server_socket.close()
        except:
            pass
        
        print("Server stopped")

class NetworkGameServer:
    """Extended server with game logic integration"""
    
    def __init__(self, game_instance):
        self.game = game_instance
        self.network_server = NetworkServer()
        self.last_sync_time = 0
        self.sync_interval = 1.0 / 30  # 30 FPS sync rate
        
    def start_server(self, host='localhost', port=5555):
        """Start the game server"""
        # Set the host and port before starting
        self.network_server.host = host
        self.network_server.port = port
        if self.network_server.start():
            # Start game sync thread
            sync_thread = threading.Thread(target=self.sync_game_loop)
            sync_thread.daemon = True
            sync_thread.start()
            return True
        return False
    
    def sync_game_loop(self):
        """Continuously sync game state to clients"""
        while self.network_server.running:
            current_time = time.time()
            
            if current_time - self.last_sync_time >= self.sync_interval:
                self.sync_game_state()
                self.last_sync_time = current_time
            
            time.sleep(0.01)  # Small delay to prevent CPU overuse
    
    def sync_game_state(self):
        """Sync current game state to all clients"""
        # Collect game state
        game_state = {
            'type': 'game_sync',
            'players': [],
            'enemies': [],
            'projectiles': [],
            'powerups': [],
            'game_time': getattr(self.game, 'game_time', 0),
            'wave': getattr(self.game.wave_manager, 'current_wave', 0) if hasattr(self.game, 'wave_manager') else 0
        }
        
        # Sync players - handle both network and local multiplayer
        if hasattr(self.game, 'multiplayer_manager') and self.game.multiplayer_manager:
            for player in self.game.multiplayer_manager.get_active_players():
                player_data = {
                    'id': getattr(player, 'player_id', 0),
                    'pos': [int(player.pos.x), int(player.pos.y)],
                    'hp': player.hp,
                    'max_hp': player.max_hp,
                    'level': getattr(player, 'level', 1),
                    'xp': getattr(player, 'xp', 0)
                }
                game_state['players'].append(player_data)
        else:
            # Network mode - sync the main player
            if hasattr(self.game, 'player'):
                player = self.game.player
                player_data = {
                    'id': 0,
                    'pos': [int(player.pos.x), int(player.pos.y)],
                    'hp': player.hp,
                    'max_hp': player.max_hp,
                    'level': getattr(player, 'level', 1),
                    'xp': getattr(player, 'xp', 0)
                }
                game_state['players'].append(player_data)
        
        # Sync enemies (limit to nearby ones for bandwidth)
        for enemy in list(self.game.enemies)[:20]:  # Limit to 20 enemies
            enemy_data = {
                'id': id(enemy),
                'pos': [int(enemy.pos.x), int(enemy.pos.y)],
                'hp': enemy.hp,
                'max_hp': enemy.max_hp,
                'type': enemy.enemy_type.value if hasattr(enemy, 'enemy_type') else 'basic'
            }
            game_state['enemies'].append(enemy_data)
        
        # Sync projectiles (limit to recent ones)
        for projectile in list(self.game.projectiles)[:30]:  # Limit to 30 projectiles
            proj_data = {
                'id': id(projectile),
                'pos': [int(projectile.pos.x), int(projectile.pos.y)],
                'vel': [int(projectile.vel.x), int(projectile.vel.y)],
                'damage': projectile.damage,
                'type': projectile.projectile_type.value if hasattr(projectile, 'projectile_type') else 'basic'
            }
            game_state['projectiles'].append(proj_data)
        
        # Broadcast to all clients
        self.network_server.broadcast(game_state)
    
    def setup_server_callbacks(self):
        """Set up server message callbacks"""
        def on_player_joined(client_id, player_data):
            self.connected_players.append(client_id)
            print(f"Player {client_id} joined")
        
        # Set up callback for player joining
        if self.network_server:
            self.network_server.connected_players = []
    
    def stop_server(self):
        """Stop the game server"""
        self.network_server.stop()
