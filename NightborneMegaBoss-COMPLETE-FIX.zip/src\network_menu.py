import pygame
import socket
import threading
import time
try:
    import pyperclip
    CLIPBOARD_AVAILABLE = True
except ImportError:
    CLIPBOARD_AVAILABLE = False
from network_server import NetworkServer, NetworkGameServer
from network_client import NetworkClient, NetworkGameClient

class NetworkMenu:
    """Menu for network multiplayer (host/join)"""
    
    def __init__(self, screen_width, screen_height):
        self.screen_width = screen_width
        self.screen_height = screen_height
        
        self.font_large = pygame.font.Font(None, 64)
        self.font_medium = pygame.font.Font(None, 48)
        self.font_small = pygame.font.Font(None, 32)
        
        # Menu state
        self.state = "main"  # main, hosting, joining, waiting
        self.selected_option = 0
        self.menu_options = ["Host Game", "Join Game", "Back"]
        
        # Network components
        self.server = None
        self.game_server = None
        self.client = None
        self.game_client = None
        
        # Connection info
        self.host_ip = "localhost"
        self.port = "5555"
        self.public_ip = None
        self.local_ip = None
        self.join_link = None
        self.input_active = None  # 'host' or 'port'
        self.connecting = False
        self.connection_message = ""
        
        # Get IP addresses immediately
        self.get_ip_addresses()
        
        # Ensure join_link is always set
        if not self.join_link:
            self.join_link = f"{self.local_ip}:{self.port}"
        
        # Server info
        self.connected_players = []
        self.server_running = False
        self.start_countdown = 0
        self.countdown_active = False
        
        # UI Elements
        self.buttons = []
        self.create_buttons()
        
    def get_ip_addresses(self):
        """Get local and public IP addresses"""
        try:
            # Get local IP
            self.local_ip = socket.gethostbyname(socket.gethostname())
            
            # Try to get public IP using socket (connect to external server)
            try:
                # Connect to a public DNS server to get local IP that would be used for internet
                s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                s.connect(("8.8.8.8", 80))
                self.public_ip = s.getsockname()[0]
                s.close()
                
                # If public IP is same as local, we're likely behind NAT
                if self.public_ip == self.local_ip or self.public_ip.startswith("192.168.") or self.public_ip.startswith("10.") or self.public_ip.startswith("172."):
                    self.public_ip = "Check router settings"
            except:
                self.public_ip = "Check router settings"
            
            # Generate join link - prioritize local IP for LAN play
            if self.public_ip and self.public_ip != "Check router settings":
                self.join_link = f"{self.public_ip}:{self.port}"
            else:
                self.join_link = f"{self.local_ip}:{self.port}"
            
            # IP Detection completed
                
        except Exception as e:
            print(f"Error getting IP addresses: {e}")
            self.local_ip = "127.0.0.1"
            self.public_ip = "Check router settings"
            self.join_link = f"{self.local_ip}:{self.port}"
            # Fallback IP completed
    
    def create_buttons(self):
        """Create UI buttons"""
        button_width = 300
        button_height = 60
        button_x = self.screen_width // 2 - button_width // 2
        
        self.buttons = {
            'host': pygame.Rect(button_x, 250, button_width, button_height),
            'join': pygame.Rect(button_x, 330, button_width, button_height),
            'back': pygame.Rect(button_x, 410, button_width, button_height),
            'start': pygame.Rect(button_x, 490, button_width, button_height),
            'connect': pygame.Rect(button_x, 490, button_width, button_height),
            'copy_link': pygame.Rect(button_x + 320, 210, 100, 40),  # Copy button next to join link
        }
    
    def handle_event(self, event):
        """Handle menu events"""
        if event.type == pygame.KEYDOWN:
            if self.state == "main":
                self.handle_main_menu_input(event)
            elif self.state == "hosting":
                self.handle_hosting_input(event)
            elif self.state == "joining":
                self.handle_joining_input(event)
            elif self.state == "waiting":
                self.handle_waiting_input(event)
        
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:  # Left click
                mouse_pos = pygame.mouse.get_pos()
                self.handle_mouse_click(mouse_pos)
        
        return None
    
    def handle_main_menu_input(self, event):
        """Handle main menu input"""
        if event.key == pygame.K_UP:
            self.selected_option = (self.selected_option - 1) % len(self.menu_options)
        elif event.key == pygame.K_DOWN:
            self.selected_option = (self.selected_option + 1) % len(self.menu_options)
        elif event.key == pygame.K_RETURN:
            choice = self.menu_options[self.selected_option]
            if choice == "Host Game":
                self.start_hosting()
            elif choice == "Join Game":
                self.start_joining()
            elif choice == "Back":
                return "back"
        elif event.key == pygame.K_ESCAPE:
            return "back"
    
    def handle_hosting_input(self, event):
        """Handle hosting menu input"""
        if event.key == pygame.K_ESCAPE:
            self.stop_hosting()
            self.state = "main"
        elif event.key == pygame.K_RETURN:
            if self.server_running and len(self.connected_players) > 0:
                self.start_game_countdown()
    
    def handle_joining_input(self, event):
        """Handle joining menu input"""
        if event.key == pygame.K_ESCAPE:
            self.state = "main"
            self.connecting = False
        elif event.key == pygame.K_RETURN:
            if not self.connecting:
                self.connect_to_server()
        elif event.key == pygame.K_TAB:
            # Switch between input fields
            if self.input_active == 'host':
                self.input_active = 'port'
            else:
                self.input_active = 'host'
        elif self.input_active:
            if event.key == pygame.K_BACKSPACE:
                if self.input_active == 'host':
                    self.host_ip = self.host_ip[:-1]
                else:
                    self.port = self.port[:-1]
            else:
                char = event.unicode
                if char.isdigit() or char == '.':
                    if self.input_active == 'host':
                        if len(self.host_ip) < 15:
                            self.host_ip += char
                    else:
                        if len(self.port) < 5:
                            self.port += char
    
    def handle_waiting_input(self, event):
        """Handle waiting room input"""
        if event.key == pygame.K_ESCAPE:
            if self.client:
                self.client.disconnect()
            self.state = "main"
    
    def handle_mouse_click(self, mouse_pos):
        """Handle mouse clicks"""
        if self.state == "main":
            if self.buttons['host'].collidepoint(mouse_pos):
                self.start_hosting()
            elif self.buttons['join'].collidepoint(mouse_pos):
                self.start_joining()
            elif self.buttons['back'].collidepoint(mouse_pos):
                return "back"
        
        elif self.state == "hosting":
            if self.buttons['start'].collidepoint(mouse_pos):
                if self.server_running and len(self.connected_players) > 0:
                    self.start_game_countdown()
            elif self.buttons['copy_link'].collidepoint(mouse_pos):
                self.copy_join_link()
            elif self.buttons['back'].collidepoint(mouse_pos):
                self.stop_hosting()
                self.state = "main"
        
        elif self.state == "joining":
            # Check input field clicks
            host_rect = pygame.Rect(self.screen_width//2 - 150, 250, 300, 40)
            port_rect = pygame.Rect(self.screen_width//2 - 150, 320, 300, 40)
            
            if host_rect.collidepoint(mouse_pos):
                self.input_active = 'host'
            elif port_rect.collidepoint(mouse_pos):
                self.input_active = 'port'
            elif self.buttons['connect'].collidepoint(mouse_pos):
                if not self.connecting:
                    self.connect_to_server()
            elif self.buttons['back'].collidepoint(mouse_pos):
                self.state = "main"
                self.connecting = False
    
    def start_hosting(self):
        """Start hosting a game"""
        self.state = "hosting"
        self.server = NetworkServer()
        self.game_server = NetworkGameServer(None)  # Will be set when game starts
        
        # Start the basic server for lobby connections
        if self.server.start():
            self.server_running = True
            print(f"Server started on {self.host_ip}:{self.port}")
            
            # Set up server callbacks
            self.setup_server_callbacks()
        else:
            self.connection_message = "Failed to start server"
            self.state = "main"
    
    def stop_hosting(self):
        """Stop hosting"""
        if self.game_server:
            self.game_server.stop_server()
        if self.server:
            self.server.stop()
        
        self.server_running = False
        self.connected_players = []
    
    def start_joining(self):
        """Start joining process"""
        self.state = "joining"
        self.input_active = 'host'
        self.connecting = False
        self.connection_message = ""
    
    def connect_to_server(self):
        """Connect to server"""
        try:
            port_int = int(self.port)
            self.client = NetworkClient()
            self.game_client = NetworkGameClient(None)  # Will be set when game starts
            
            # Set up client callbacks
            self.setup_client_callbacks()
            
            if self.client.connect(self.host_ip, port_int):
                self.connecting = True
                self.connection_message = "Connecting..."
                self.state = "waiting"
            else:
                self.connection_message = "Failed to connect"
        
        except ValueError:
            self.connection_message = "Invalid port number"
    
    def setup_server_callbacks(self):
        """Set up server message callbacks"""
        # Update connected players list when clients join/leave
        if self.server:
            self.connected_players = list(self.server.clients.keys())
    
    def setup_client_callbacks(self):
        """Set up client message callbacks"""
        def on_welcome(message):
            self.connection_message = f"Connected as Player {message.get('client_id')}"
            self.state = "waiting"
        
        def on_game_state(message):
            server_info = message.get('server_info', {})
            self.connected_players = list(range(1, server_info.get('current_players', 0) + 1))
        
        def on_game_started(message):
            # Start the game
            if self.game_client:
                return "start_network_client"
        
        self.client.set_callback('welcome', on_welcome)
        self.client.set_callback('game_state', on_game_state)
        self.client.set_callback('game_started', on_game_started)
    
    def start_game_countdown(self):
        """Start countdown to begin game"""
        self.countdown_active = True
        self.start_countdown = 3.0
    
    def update(self, dt):
        """Update menu state"""
        if self.countdown_active:
            self.start_countdown -= dt
            if self.start_countdown <= 0:
                self.countdown_active = False
                if self.server_running:
                    # Start game as host
                    return "start_network_host"
        
        # Update connection message
        if self.connecting and self.client:
            if not self.client.connected:
                self.connection_message = "Connection failed"
                self.connecting = False
                self.state = "joining"
        
        # Update connected players list for server
        if self.server and self.server_running:
            self.connected_players = list(self.server.clients.keys())
        
        return None
    
    def draw(self, screen):
        """Draw the network menu"""
        screen.fill((20, 20, 40))
        
        if self.state == "main":
            self.draw_main_menu(screen)
        elif self.state == "hosting":
            self.draw_hosting_menu(screen)
        elif self.state == "joining":
            self.draw_joining_menu(screen)
        elif self.state == "waiting":
            self.draw_waiting_menu(screen)
    
    def draw_main_menu(self, screen):
        """Draw main network menu"""
        # Title
        title_text = self.font_large.render("NETWORK MULTIPLAYER", True, (255, 255, 255))
        title_rect = title_text.get_rect(center=(self.screen_width // 2, 100))
        screen.blit(title_text, title_rect)
        
        # Subtitle
        subtitle_text = self.font_small.render("Host or join a multiplayer game", True, (200, 200, 200))
        subtitle_rect = subtitle_text.get_rect(center=(self.screen_width // 2, 150))
        screen.blit(subtitle_text, subtitle_rect)
        
        # Draw buttons
        mouse_pos = pygame.mouse.get_pos()
        for i, option in enumerate(self.menu_options):
            button_key = option.lower().replace(" ", "_")
            if button_key in self.buttons:
                button = self.buttons[button_key]
                
                # Highlight selected option
                color = (100, 150, 200) if i == self.selected_option else (80, 80, 120)
                if button.collidepoint(mouse_pos):
                    color = (120, 170, 220)
                
                pygame.draw.rect(screen, color, button, border_radius=8)
                
                # Draw text
                text = self.font_medium.render(option, True, (255, 255, 255))
                text_rect = text.get_rect(center=button.center)
                screen.blit(text, text_rect)
    
    def draw_hosting_menu(self, screen):
        """Draw hosting menu"""
        # Title
        title_text = self.font_large.render("HOSTING GAME", True, (255, 255, 255))
        title_rect = title_text.get_rect(center=(self.screen_width // 2, 60))
        screen.blit(title_text, title_rect)
        
        # Status
        if self.server_running:
            status_text = f"Server Running - Players: {len(self.connected_players)}/4"
            status_color = (0, 255, 100)
        else:
            status_text = "Starting Server..."
            status_color = (255, 200, 100)
        
        status_surface = self.font_small.render(status_text, True, status_color)
        status_rect = status_surface.get_rect(center=(self.screen_width // 2, 100))
        screen.blit(status_surface, status_rect)
        
        # Join Link - Most important info
        if not self.join_link:
            self.join_link = f"{self.local_ip}:{self.port}"
        
        # Join link section
        link_y = 150
        
        # Label
        link_label = self.font_small.render("PLAYERS JOIN USING:", True, (200, 200, 200))
        link_label_rect = link_label.get_rect(center=(self.screen_width // 2, link_y))
        screen.blit(link_label, link_label_rect)
        
        # Instructions
        inst_text = self.font_small.render("Players must run the game and use 'Join Game' option", True, (150, 150, 150))
        inst_rect = inst_text.get_rect(center=(self.screen_width // 2, link_y + 20))
        screen.blit(inst_text, inst_rect)
        
        # Join link (prominent)
        link_text = self.font_medium.render(self.join_link, True, (100, 255, 100))
        link_rect = link_text.get_rect(center=(self.screen_width // 2, link_y + 35))
        
        # Background box
        padding = 15
        bg_rect = link_rect.inflate(padding * 2, padding)
        pygame.draw.rect(screen, (30, 50, 30), bg_rect, border_radius=8)
        pygame.draw.rect(screen, (100, 255, 100), bg_rect, 2, border_radius=8)
        
        screen.blit(link_text, link_rect)
        
        # Copy button - use predefined position
        copy_button = self.buttons['copy_link']
        pygame.draw.rect(screen, (80, 120, 80), copy_button, border_radius=5)
        pygame.draw.rect(screen, (100, 255, 100), copy_button, 2, border_radius=5)
        
        copy_text = self.font_small.render("COPY", True, (255, 255, 255))
        copy_rect = copy_text.get_rect(center=copy_button.center)
        screen.blit(copy_text, copy_rect)
        
        # Connected players section
        players_y = 220
        players_label = self.font_small.render("CONNECTED PLAYERS", True, (180, 180, 180))
        players_label_rect = players_label.get_rect(center=(self.screen_width // 2, players_y))
        screen.blit(players_label, players_label_rect)
        
        players_y += 30
        if self.connected_players:
            for i, player_id in enumerate(self.connected_players[:4]):
                colors = [(0, 200, 255), (0, 255, 100), (255, 100, 100), (255, 255, 100)]
                color = colors[i % len(colors)]
                player_text = self.font_small.render(f"Player {player_id}", True, color)
                player_rect = player_text.get_rect(center=(self.screen_width // 2, players_y))
                screen.blit(player_text, player_rect)
                players_y += 25
        else:
            no_players_text = self.font_small.render("Waiting for players...", True, (120, 120, 120))
            no_players_rect = no_players_text.get_rect(center=(self.screen_width // 2, players_y))
            screen.blit(no_players_text, no_players_rect)
        
        # Action buttons
        button_y = 400
        
        # Start button (if players connected)
        if self.server_running and len(self.connected_players) > 0:
            if self.countdown_active:
                countdown_text = self.font_medium.render(f"Starting in {int(self.start_countdown) + 1}...", True, (255, 255, 100))
                countdown_rect = countdown_text.get_rect(center=(self.screen_width // 2, button_y))
                screen.blit(countdown_text, countdown_rect)
            else:
                start_button = pygame.Rect(self.screen_width//2 - 100, button_y - 20, 200, 50)
                pygame.draw.rect(screen, (0, 200, 100), start_button, border_radius=8)
                start_text = self.font_medium.render("Start Game", True, (255, 255, 255))
                start_rect = start_text.get_rect(center=start_button.center)
                screen.blit(start_text, start_rect)
                self.buttons['start'] = start_button
        
        # Back button
        back_button = pygame.Rect(self.screen_width//2 - 100, button_y + 60, 200, 50)
        pygame.draw.rect(screen, (150, 100, 100), back_button, border_radius=8)
        back_text = self.font_medium.render("Back", True, (255, 255, 255))
        back_rect = back_text.get_rect(center=back_button.center)
        screen.blit(back_text, back_rect)
        self.buttons['back'] = back_button
    
    def draw_joining_menu(self, screen):
        """Draw joining menu"""
        # Title
        title_text = self.font_large.render("JOIN GAME", True, (255, 255, 255))
        title_rect = title_text.get_rect(center=(self.screen_width // 2, 80))
        screen.blit(title_text, title_rect)
        
        # Input section
        input_y = 180
        
        # Host input
        host_rect = pygame.Rect(self.screen_width//2 - 150, input_y, 300, 40)
        pygame.draw.rect(screen, (60, 60, 80), host_rect, border_radius=5)
        border_color = (100, 200, 100) if self.input_active == 'host' else (100, 100, 150)
        pygame.draw.rect(screen, border_color, host_rect, 2, border_radius=5)
        
        host_text = self.font_small.render(f"Host: {self.host_ip}", True, (255, 255, 255))
        host_text_rect = host_text.get_rect(midleft=(host_rect.x + 10, host_rect.centery))
        screen.blit(host_text, host_text_rect)
        
        # Port input
        input_y += 60
        port_rect = pygame.Rect(self.screen_width//2 - 150, input_y, 300, 40)
        pygame.draw.rect(screen, (60, 60, 80), port_rect, border_radius=5)
        border_color = (100, 200, 100) if self.input_active == 'port' else (100, 100, 150)
        pygame.draw.rect(screen, border_color, port_rect, 2, border_radius=5)
        
        port_text = self.font_small.render(f"Port: {self.port}", True, (255, 255, 255))
        port_text_rect = port_text.get_rect(midleft=(port_rect.x + 10, port_rect.centery))
        screen.blit(port_text, port_text_rect)
        
        # Connection message
        if self.connection_message:
            msg_y = input_y + 80
            msg_color = (255, 100, 100) if "failed" in self.connection_message.lower() or "refused" in self.connection_message.lower() else (100, 255, 100)
            msg_surface = self.font_small.render(self.connection_message, True, msg_color)
            msg_rect = msg_surface.get_rect(center=(self.screen_width // 2, msg_y))
            screen.blit(msg_surface, msg_rect)
        
        # Buttons
        button_y = input_y + 140
        
        # Connect button - use predefined position
        if not self.connecting:
            connect_button = self.buttons['connect']
            pygame.draw.rect(screen, (0, 150, 100), connect_button, border_radius=8)
            connect_text = self.font_medium.render("Connect", True, (255, 255, 255))
            connect_rect = connect_text.get_rect(center=connect_button.center)
            screen.blit(connect_text, connect_rect)
        
        # Back button - use predefined position
        back_button = self.buttons['back']
        pygame.draw.rect(screen, (150, 100, 100), back_button, border_radius=8)
        back_text = self.font_medium.render("Back", True, (255, 255, 255))
        back_rect = back_text.get_rect(center=back_button.center)
        screen.blit(back_text, back_rect)
        
        # Instructions
        inst_text = self.font_small.render("Click on fields to edit, then press Connect", True, (150, 150, 150))
        inst_rect = inst_text.get_rect(center=(self.screen_width // 2, 480))
        screen.blit(inst_text, inst_rect)
    
    def draw_waiting_menu(self, screen):
        """Draw waiting room"""
        # Title
        title_text = self.font_large.render("WAITING ROOM", True, (255, 255, 255))
        title_rect = title_text.get_rect(center=(self.screen_width // 2, 100))
        screen.blit(title_text, title_rect)
        
        # Connection message
        msg_text = self.font_medium.render(self.connection_message, True, (200, 200, 200))
        msg_rect = msg_text.get_rect(center=(self.screen_width // 2, 200))
        screen.blit(msg_text, msg_rect)
        
        # Players
        if self.client:
            players = self.client.get_server_players()
            y_offset = 300
            for player_id, player_data in players.items():
                color = player_data.get('color', (255, 255, 255))
                player_text = self.font_small.render(f"Player {player_id}", True, color)
                player_rect = player_text.get_rect(center=(self.screen_width // 2, y_offset))
                screen.blit(player_text, player_rect)
                y_offset += 40
        
        # Waiting message
        wait_text = self.font_small.render("Waiting for host to start game...", True, (150, 150, 150))
        wait_rect = wait_text.get_rect(center=(self.screen_width // 2, 500))
        screen.blit(wait_text, wait_rect)
        
        # Back instruction
        back_text = self.font_small.render("Press ESC to go back", True, (150, 150, 150))
        back_rect = back_text.get_rect(center=(self.screen_width // 2, self.screen_height - 50))
        screen.blit(back_text, back_rect)
    
    def copy_join_link(self):
        """Copy join link to clipboard"""
        try:
            if self.join_link:
                if CLIPBOARD_AVAILABLE:
                    pyperclip.copy(self.join_link)
                    print(f"Copied to clipboard: {self.join_link}")
                    return True
                else:
                    # Fallback: try Windows clipboard
                    try:
                        import ctypes
                        GMEM_DDESHARE = 0x2000
                        ctypes.windll.user32.OpenClipboard(0)
                        ctypes.windll.user32.EmptyClipboard()
                        handle = ctypes.windll.kernel32.GlobalAlloc(GMEM_DDESHARE, len(self.join_link) + 1)
                        ctypes.windll.kernel32.GlobalLock(handle)
                        ctypes.windll.kernel32.GlobalUnlock(handle)
                        ctypes.windll.user32.SetClipboardData(1, handle)
                        ctypes.windll.user32.CloseClipboard()
                        print(f"Copied to clipboard: {self.join_link}")
                        return True
                    except:
                        print(f"Clipboard not available. Link: {self.join_link}")
                        return False
        except Exception as e:
            print(f"Failed to copy to clipboard: {e}")
            print(f"Link to share manually: {self.join_link}")
        return False
    
    def get_network_mode(self):
        """Get network mode and components"""
        if self.state == "hosting" and self.server_running:
            return "start_network_host", self.server, self.game_server
        elif self.state == "waiting" and self.client and self.client.connected:
            return "start_network_client", self.client, self.game_client
        return None, None, None
