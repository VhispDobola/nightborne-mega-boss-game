#!/usr/bin/env python3
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

import pygame
from game import Game

def test_game():
    print("Starting game test...")
    
    # Initialize pygame
    pygame.init()
    
    # Create game
    game = Game()
    print("Game created successfully!")
    print("Game window should be visible now...")
    print("Press ESC or close window to exit")
    
    # Run game for a few seconds to test
    clock = pygame.time.Clock()
    running = True
    frame_count = 0
    
    while running and frame_count < 300:  # Run for 5 seconds at 60 FPS
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
        
        # Update and draw
        game.update(1/60)
        game.draw()
        pygame.display.flip()
        
        clock.tick(60)
        frame_count += 1
    
    print("Test completed successfully!")
    pygame.quit()

if __name__ == "__main__":
    test_game()
