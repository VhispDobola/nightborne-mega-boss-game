import pygame
import random
from projectile import ProjectileType, Weapon

class Upgrade:
    """Base class for upgrades"""
    def __init__(self, title, description, apply_func):
        self.title = title
        self.description = description
        self.apply_func = apply_func
    
    def apply(self, player):
        """Apply this upgrade to the player"""
        self.apply_func(player)

class UpgradeManager:
    def __init__(self, game):
        self.game = game
        self.waiting = False
        self.options = []
        self.selected_upgrade = None
        
        # Define all possible upgrades
        self.all_upgrades = self.create_upgrades()
        
    def create_upgrades(self):
        """Create all available upgrades that add abilities to existing weapons"""
        upgrades = [
            # Damage upgrades
            Upgrade("Damage +5", "Increase projectile damage by 5", 
                   lambda p: self.apply_stat_upgrade(p, 'damage', 5)),
            Upgrade("Damage +10", "Increase projectile damage by 10", 
                   lambda p: self.apply_stat_upgrade(p, 'damage', 10)),
            Upgrade("Damage +20%", "Increase projectile damage by 20%", 
                   lambda p: self.apply_stat_upgrade(p, 'damage', int(p.damage * 0.2))),
            
            # Fire rate upgrades
            Upgrade("Fire Rate +0.5", "Increase fire rate by 0.5 shots/sec", 
                   lambda p: self.apply_stat_upgrade(p, 'fire_rate', 0.5)),
            Upgrade("Fire Rate +100%", "Double your fire rate", 
                   lambda p: self.apply_stat_upgrade(p, 'fire_rate', p.fire_rate)),
            
            # Movement upgrades
            Upgrade("Move Speed +30", "Increase movement speed by 30", 
                   lambda p: self.apply_stat_upgrade(p, 'speed', 30)),
            Upgrade("Move Speed +20%", "Increase movement speed by 20%", 
                   lambda p: self.apply_stat_upgrade(p, 'speed', int(p.speed * 0.2))),
            
            # Projectile upgrades
            Upgrade("+1 Projectile", "Fire one additional projectile", 
                   lambda p: self.increase_projectile_count(p, 1)),
            Upgrade("+2 Projectiles", "Fire two additional projectiles", 
                   lambda p: self.increase_projectile_count(p, 2)),
            
            # Projectile speed
            Upgrade("Projectile Speed +100", "Increase projectile speed by 100", 
                   lambda p: setattr(p, 'projectile_speed', p.projectile_speed + 100)),
            
            # Pickup range
            Upgrade("Pickup Range +20", "Increase XP pickup range by 20", 
                   lambda p: setattr(p, 'pickup_range', p.pickup_range + 20)),
            Upgrade("Pickup Range +50%", "Increase XP pickup range by 50%", 
                   lambda p: setattr(p, 'pickup_range', int(p.pickup_range * 1.5))),
            
            # Health upgrades
            Upgrade("Heal 50", "Restore 50 HP", 
                   lambda p: p.heal(50)),
            Upgrade("Heal Full", "Restore full health", 
                   lambda p: p.heal(p.max_hp)),
            Upgrade("Max HP +20", "Increase maximum HP by 20", 
                   lambda p: self.increase_max_hp(p, 20)),
            Upgrade("Max HP +50", "Increase maximum HP by 50", 
                   lambda p: self.increase_max_hp(p, 50)),
            
            # NEW: Ability-based upgrades that stack on existing weapon
            Upgrade("Add Explosive", "Your weapons gain explosive damage", 
                   lambda p: self.add_weapon_ability(p, ProjectileType.EXPLOSIVE)),
            Upgrade("Add Homing", "Your projectiles home toward enemies", 
                   lambda p: self.add_weapon_ability(p, ProjectileType.HOMING)),
            Upgrade("Add Piercing", "Your projectiles pierce through enemies", 
                   lambda p: self.add_weapon_ability(p, ProjectileType.PIERCING)),
            Upgrade("Add Bouncing", "Your projectiles bounce off walls", 
                   lambda p: self.add_weapon_ability(p, ProjectileType.BOUNCING)),
            Upgrade("Add Rapid Fire", "Greatly increased fire rate", 
                   lambda p: self.add_weapon_ability(p, ProjectileType.RAPID)),
            Upgrade("Add Spread Shot", "Fire projectiles in a spread pattern", 
                   lambda p: self.add_weapon_ability(p, ProjectileType.SPREAD)),
            Upgrade("Add Laser", "Omnidirectional laser damage", 
                   lambda p: self.add_weapon_ability(p, ProjectileType.LASER)),
            
            # NEW: Range and area upgrades
            Upgrade("Projectile Range +50%", "Increase projectile travel distance by 50%", 
                   lambda p: self.increase_projectile_range(p, 0.5)),
            Upgrade("Projectile Range +100%", "Double projectile travel distance", 
                   lambda p: self.increase_projectile_range(p, 1.0)),
            Upgrade("Explosion Radius +30%", "Increase explosion size by 30%", 
                   lambda p: self.increase_explosion_radius(p, 0.3)),
            Upgrade("Damage Radius +25%", "Increase all damage area effects by 25%", 
                   lambda p: self.increase_damage_radius(p, 0.25)),
            Upgrade("Pickup Range +40%", "Increase XP pickup range by 40%", 
                   lambda p: self.apply_stat_upgrade(p, 'pickup_range', int(p.pickup_range * 0.4))),
            
            # NEW: Active ability upgrades
            Upgrade("Active: Blast Wave", "Press SPACE to clear nearby enemies", 
                   lambda p: self.add_active_ability(p, 'blast_wave')),
            Upgrade("Active: Time Slow", "Press SHIFT to slow time for 3 seconds", 
                   lambda p: self.add_active_ability(p, 'time_slow')),
            Upgrade("Active: Shield Burst", "Press F to create protective shield burst", 
                   lambda p: self.add_active_ability(p, 'shield_burst')),
            Upgrade("Active: Teleport", "Press E to teleport to mouse position", 
                   lambda p: self.add_active_ability(p, 'teleport')),
            Upgrade("Active: Meteor Strike", "Press Q to call down meteor strike", 
                   lambda p: self.add_active_ability(p, 'meteor_strike')),
            
            # NEW: Passive effect upgrades
            Upgrade("Passive: Life Steal", "Heal for 10% of damage dealt", 
                   lambda p: self.add_passive_ability(p, 'life_steal')),
            Upgrade("Passive: Revenge", "Explode when taking damage", 
                   lambda p: self.add_passive_ability(p, 'revenge')),
            Upgrade("Passive: Magnet", "Automatically attract nearby XP", 
                   lambda p: self.add_passive_ability(p, 'magnet')),
            Upgrade("Passive: Adrenaline", "Move faster when at low health", 
                   lambda p: self.add_passive_ability(p, 'adrenaline')),
            Upgrade("Passive: Critical Hits", "10% chance for double damage", 
                   lambda p: self.add_passive_ability(p, 'critical')),
            
            # NEW: Defensive upgrades
            Upgrade("Armor +5", "Reduce all damage taken by 5", 
                   lambda p: self.increase_armor(p, 5)),
            Upgrade("Armor +10", "Reduce all damage taken by 10", 
                   lambda p: self.increase_armor(p, 10)),
            Upgrade("Evasion +10%", "10% chance to dodge incoming attacks", 
                   lambda p: self.increase_evasion(p, 0.1)),
            Upgrade("Regeneration", "Regenerate 1 HP per second", 
                   lambda p: self.add_regeneration(p, 1)),
            Upgrade("Second Wind", "Heal to 50% HP when taking fatal damage", 
                   lambda p: self.add_passive_ability(p, 'second_wind')),
            
            # Multi-ability upgrades
            Upgrade("Explosive + Homing", "Combine explosive and homing abilities", 
                   lambda p: self.add_multiple_abilities(p, [ProjectileType.EXPLOSIVE, ProjectileType.HOMING])),
            Upgrade("Piercing + Bouncing", "Combine piercing and bouncing abilities", 
                   lambda p: self.add_multiple_abilities(p, [ProjectileType.PIERCING, ProjectileType.BOUNCING])),
            Upgrade("Spread + Rapid Fire", "Combine spread and rapid fire abilities", 
                   lambda p: self.add_multiple_abilities(p, [ProjectileType.SPREAD, ProjectileType.RAPID])),
            Upgrade("Laser + Explosive", "Combine laser and explosive abilities", 
                   lambda p: self.add_multiple_abilities(p, [ProjectileType.LASER, ProjectileType.EXPLOSIVE])),
            
            # Enhancement upgrades (can be stacked)
            Upgrade("Enhance Weapon +1", "Increase current weapon power", 
                   lambda p: self.enhance_weapon(p, 1)),
            Upgrade("Enhance Weapon +2", "Greatly increase current weapon power", 
                   lambda p: self.enhance_weapon(p, 2)),
            
            # Ultimate upgrades
            Upgrade("Ultimate Damage", "Massive damage increase", 
                   lambda p: self.ultimate_upgrade(p, 'damage')),
            Upgrade("Ultimate Fire Rate", "Extreme fire rate boost", 
                   lambda p: self.ultimate_upgrade(p, 'fire_rate')),
            Upgrade("Ultimate Speed", "Maximum movement speed", 
                   lambda p: self.ultimate_upgrade(p, 'speed')),
            Upgrade("Ultimate Health", "Double max HP and full heal", 
                   lambda p: self.ultimate_upgrade(p, 'health')),
        ]
        
        return upgrades
    
    def increase_max_hp(self, player, amount):
        """Increase max HP and heal proportionally"""
        player.max_hp += amount
        player.hp = min(player.hp + amount, player.max_hp)
    
    def add_weapon_ability(self, player, ability_type):
        """Add an ability to the player's current weapon"""
        if hasattr(player, 'weapon') and player.weapon:
            player.weapon.add_ability(ability_type)
            
            # Show announcement about new ability
            ability_name = ability_type.value.replace('_', ' ').title()
            if hasattr(self.game, 'floating_text'):
                self.game.floating_text.add_announcement(
                    player.rect.center,
                    f"Added {ability_name}!",
                    (100, 255, 100)
                )
    
    def add_multiple_abilities(self, player, ability_types):
        """Add multiple abilities to the player's weapon"""
        if hasattr(player, 'weapon') and player.weapon:
            for ability_type in ability_types:
                player.weapon.add_ability(ability_type)
            
            # Show announcement about combined abilities
            ability_names = [ability.value.replace('_', ' ').title() for ability in ability_types]
            combined_name = " + ".join(ability_names)
            if hasattr(self.game, 'floating_text'):
                self.game.floating_text.add_announcement(
                    player.rect.center,
                    f"Added {combined_name}!",
                    (255, 200, 100)
                )
    
    def enhance_weapon(self, player, levels):
        """Enhance current weapon by increasing its level"""
        if not hasattr(player, 'weapon_level'):
            player.weapon_level = 1
        
        player.weapon_level += levels
        player.damage += levels * 5  # Increase base damage
        player.fire_rate *= 1.2  # Slightly increase fire rate
        
        # Update pre-powerup stats for new baseline
        player.update_pre_powerup_stats()
    
    def ultimate_upgrade(self, player, upgrade_type):
        """Apply ultimate upgrade based on type"""
        if upgrade_type == 'damage':
            player.damage += 50
            player.weapon_level += 2
        elif upgrade_type == 'fire_rate':
            player.fire_rate *= 2.5
        elif upgrade_type == 'speed':
            player.speed = min(player.speed + 100, 500)
        elif upgrade_type == 'health':
            player.max_hp *= 2
            player.hp = player.max_hp
        
        # Update pre-powerup stats for new baseline
        player.update_pre_powerup_stats()
    
    # NEW: Range and area upgrade methods
    def increase_projectile_range(self, player, multiplier):
        """Increase projectile travel distance"""
        if not hasattr(player, 'projectile_range_multiplier'):
            player.projectile_range_multiplier = 1.0
        player.projectile_range_multiplier += multiplier
        player.update_pre_powerup_stats()
    
    def increase_explosion_radius(self, player, multiplier):
        """Increase explosion radius for explosive projectiles"""
        if not hasattr(player, 'explosion_radius_multiplier'):
            player.explosion_radius_multiplier = 1.0
        player.explosion_radius_multiplier += multiplier
        player.update_pre_powerup_stats()
    
    def increase_damage_radius(self, player, multiplier):
        """Increase all damage area effects"""
        if not hasattr(player, 'damage_radius_multiplier'):
            player.damage_radius_multiplier = 1.0
        player.damage_radius_multiplier += multiplier
        player.update_pre_powerup_stats()
    
    # NEW: Active ability methods
    def add_active_ability(self, player, ability_type):
        """Add an active ability to the player"""
        if not hasattr(player, 'active_abilities'):
            player.active_abilities = []
        if ability_type not in player.active_abilities:
            player.active_abilities.append(ability_type)
            
            # Show announcement about new active ability
            ability_names = {
                'blast_wave': 'Blast Wave (SPACE)',
                'time_slow': 'Time Slow (SHIFT)',
                'shield_burst': 'Shield Burst (F)',
                'teleport': 'Teleport (E)',
                'meteor_strike': 'Meteor Strike (Q)'
            }
            ability_name = ability_names.get(ability_type, ability_type.replace('_', ' ').title())
            if hasattr(self.game, 'floating_text'):
                self.game.floating_text.add_announcement(
                    player.rect.center,
                    f"Active: {ability_name}!",
                    (255, 200, 100)
                )
    
    # NEW: Passive ability methods
    def add_passive_ability(self, player, ability_type):
        """Add a passive ability to the player"""
        if not hasattr(player, 'passive_abilities'):
            player.passive_abilities = []
        if ability_type not in player.passive_abilities:
            player.passive_abilities.append(ability_type)
            
            # Initialize passive ability stats
            if ability_type == 'life_steal':
                player.life_steal_percent = 0.1  # 10% lifesteal
            elif ability_type == 'critical':
                player.critical_chance = 0.1  # 10% crit chance
                player.critical_multiplier = 2.0  # 2x damage
            elif ability_type == 'magnet':
                player.magnet_range = player.pickup_range * 2  # Double pickup range
            elif ability_type == 'adrenaline':
                player.adrenaline_threshold = 0.3  # 30% HP threshold
                player.adrenaline_speed_bonus = 1.5  # 50% speed boost
            elif ability_type == 'second_wind':
                player.second_wind_used = False
                player.second_wind_threshold = 0.5  # Heal to 50% HP
            
            # Show announcement about new passive ability
            ability_names = {
                'life_steal': 'Life Steal',
                'revenge': 'Revenge Explosion',
                'magnet': 'XP Magnet',
                'adrenaline': 'Adrenaline Rush',
                'critical': 'Critical Hits',
                'second_wind': 'Second Wind'
            }
            ability_name = ability_names.get(ability_type, ability_type.replace('_', ' ').title())
            if hasattr(self.game, 'floating_text'):
                self.game.floating_text.add_announcement(
                    player.rect.center,
                    f"Passive: {ability_name}!",
                    (100, 255, 200)
                )
    
    # NEW: Defensive upgrade methods
    def increase_armor(self, player, armor_value):
        """Increase armor to reduce damage taken"""
        if not hasattr(player, 'armor'):
            player.armor = 0
        player.armor += armor_value
        player.update_pre_powerup_stats()
    
    def increase_evasion(self, player, evasion_chance):
        """Increase evasion chance"""
        if not hasattr(player, 'evasion_chance'):
            player.evasion_chance = 0.0
        player.evasion_chance += evasion_chance
        player.update_pre_powerup_stats()
    
    def add_regeneration(self, player, regen_rate):
        """Add health regeneration"""
        if not hasattr(player, 'regeneration_rate'):
            player.regeneration_rate = 0
            player.regen_timer = 0
        player.regeneration_rate += regen_rate
        player.update_pre_powerup_stats()
    
    def increase_projectile_count(self, player, count):
        """Increase weapon projectile count"""
        if hasattr(player, 'weapon') and player.weapon:
            player.weapon.projectile_count += count
            player.update_pre_powerup_stats()
            
            # Show announcement about increased projectiles
            if hasattr(self.game, 'floating_text'):
                self.game.floating_text.add_announcement(
                    player.rect.center,
                    f"+{count} Projectile{'s' if count > 1 else ''}!",
                    (255, 200, 100)
                )
    
    def waiting_for_choice(self):
        """Check if waiting for upgrade selection"""
        return self.waiting
    
    def trigger_level_up(self):
        """Trigger level up and show upgrade options"""
        self.waiting = True
        self.options = self.get_random_upgrades(3)
    
    def get_random_upgrades(self, count):
        """Get random upgrades, weighted by player needs and progression"""
        available_upgrades = self.all_upgrades.copy()
        unlocked_weapons = self.game.progression_manager.get_available_weapons()
        
        # Remove already selected upgrades that shouldn't stack
        filtered_upgrades = []
        for upgrade in available_upgrades:
            should_include = True
            
            # Don't offer piercing if already have it
            if "Piercing" in upgrade.title and self.game.player.piercing:
                should_include = False
            
            # Don't offer max HP upgrades too many times
            if "Max HP" in upgrade.title and self.game.player.max_hp > 200:
                should_include = False
            
            # Don't offer too many projectiles
            if "Projectile" in upgrade.title and self.game.player.weapon.projectile_count >= 8:
                should_include = False
            
            # Don't offer healing if at full health
            if "Heal" in upgrade.title and self.game.player.hp >= self.game.player.max_hp:
                should_include = False
            
            if should_include:
                filtered_upgrades.append(upgrade)
        
        # If no upgrades left, use all upgrades as fallback
        if not filtered_upgrades:
            filtered_upgrades = available_upgrades
        
        return random.sample(filtered_upgrades, min(count, len(filtered_upgrades)))
    
    def handle_event(self, event):
        """Handle mouse clicks for upgrade selection"""
        if not self.waiting:
            return
        
        if event.type == pygame.MOUSEBUTTONDOWN:
            mx, my = event.pos
            
            # Check which upgrade was clicked
            for i, upgrade in enumerate(self.options):
                rect = self.get_upgrade_rect(i)
                if rect.collidepoint(mx, my):
                    self.apply_upgrade(upgrade)
                    self.waiting = False
                    break
    
    def get_upgrade_rect(self, index):
        """Get rectangle for upgrade option at given index"""
        x = 200 + index * 300
        y = 250
        return pygame.Rect(x, y, 250, 120)
    
    def apply_stat_upgrade(self, player, stat, value):
        """Apply a stat upgrade and update power-up baseline"""
        if stat == 'damage':
            player.damage += value
        elif stat == 'fire_rate':
            player.fire_rate += value
        elif stat == 'speed':
            player.speed += value
        
        # Update the pre-powerup stats so power-ups work with new baseline
        player.update_pre_powerup_stats()
    
    def apply_upgrade(self, upgrade):
        """Apply selected upgrade"""
        upgrade.apply(self.game.player)
        self.selected_upgrade = upgrade
        
        # Track upgrade selection
        self.game.update_stats("upgrade_chosen")

# ... (rest of the code remains the same)
    
    def draw_ui(self):
        """Draw upgrade selection UI"""
        if not self.waiting:
            return
        
        screen = self.game.screen
        
        # Draw overlay
        overlay = pygame.Surface(screen.get_size(), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 180))
        screen.blit(overlay, (0, 0))
        
        # Draw title
        title_font = pygame.font.Font(None, 48)
        title_text = title_font.render("LEVEL UP!", True, (255, 255, 100))
        title_rect = title_text.get_rect(center=(640, 150))
        screen.blit(title_text, title_rect)
        
        # Draw subtitle
        subtitle_font = pygame.font.Font(None, 24)
        subtitle_text = subtitle_font.render("Choose an upgrade:", True, (200, 200, 200))
        subtitle_rect = subtitle_text.get_rect(center=(640, 200))
        screen.blit(subtitle_text, subtitle_rect)
        
        # Draw upgrade options
        for i, upgrade in enumerate(self.options):
            rect = self.get_upgrade_rect(i)
            
            # Draw card background
            card_color = (80, 80, 120) if i == 0 else (60, 60, 90)
            pygame.draw.rect(screen, card_color, rect, border_radius=8)
            pygame.draw.rect(screen, (120, 120, 160), rect, 2, border_radius=8)
            
            # Draw upgrade title
            font = pygame.font.Font(None, 28)
            title_text = font.render(upgrade.title, True, (255, 255, 255))
            title_rect = title_text.get_rect(center=(rect.centerx, rect.y + 30))
            screen.blit(title_text, title_rect)
            
            # Draw upgrade description
            desc_font = pygame.font.Font(None, 20)
            desc_text = desc_font.render(upgrade.description, True, (200, 200, 200))
            desc_rect = desc_text.get_rect(center=(rect.centerx, rect.y + 60))
            screen.blit(desc_text, desc_rect)
            
            # Draw hover effect
            mouse_pos = pygame.mouse.get_pos()
            if rect.collidepoint(mouse_pos):
                hover_overlay = pygame.Surface(rect.size, pygame.SRCALPHA)
                hover_overlay.fill((255, 255, 255, 30))
                screen.blit(hover_overlay, rect)
                pygame.draw.rect(screen, (200, 200, 255), rect, 3, border_radius=8)
