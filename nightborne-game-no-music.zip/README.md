# Nightborne Mega Boss Game

## Quick Start

1. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

2. Run the game:
   ```
   python start_game.py
   ```

## Multiplayer

### Host Game:
1. Start game → Multiplayer → Host Game
2. Share the IP address shown with friends
3. Wait for players to join
4. Click "Start Game" when ready

### Join Game:
1. Start game → Multiplayer → Join Game
2. Enter the host's IP address
3. Click "Connect"
4. Wait for host to start the game

## Controls
- WASD/Arrow Keys: Move
- Mouse: Aim
- Left Click: Shoot
- ESC: Pause/Menu

## Features
- Fullscreen multiplayer bullet hell
- LAN network play (up to 4 players)
- Automatic IP detection
- Real-time player synchronization
- Wave-based enemy spawning

Enjoy the game!
