#!/usr/bin/env python3
"""
Nightborne Mega Boss Game - Multiplayer Bullet Hell
Start script for easy game launching
"""

import sys
import os

# Add src directory to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

try:
    from main import main
    main()
except ImportError as e:
    print(f"Error importing game modules: {e}")
    print("\nPlease install required packages:")
    print("pip install -r requirements.txt")
    sys.exit(1)
except Exception as e:
    print(f"Error starting game: {e}")
    sys.exit(1)
