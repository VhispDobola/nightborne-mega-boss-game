import socket
import threading
import json
import time
from typing import Optional, Dict, Any, Callable
import pygame

class NetworkClient:
    """Client for connecting to multiplayer game servers"""
    
    def __init__(self):
        self.socket = None
        self.connected = False
        self.client_id = None
        self.player_color = None
        
        self.server_host = None
        self.server_port = None
        
        # Callbacks for different message types
        self.callbacks = {
            'welcome': None,
            'player_joined': None,
            'player_left': None,
            'player_update': None,
            'game_state': None,
            'game_sync': None,
            'game_started': None,
            'chat': None,
            'server_full': None,
            'error': None
        }
        
        # Network thread
        self.receive_thread = None
        self.running = False
        
        # Local state
        self.local_player_data = {
            'pos': [400, 300],
            'hp': 100,
            'max_hp': 100,
            'level': 1,
            'xp': 0,
            'active': True
        }
        
        # Server state
        self.server_players = {}
        self.game_state = "lobby"
        self.server_info = {}
    
    def connect(self, host='localhost', port=5555) -> bool:
        """Connect to server"""
        try:
            print(f"Attempting to connect to {host}:{port}")
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.socket.settimeout(5.0)  # 5 second timeout
            self.socket.connect((host, port))
            
            print(f"Successfully connected to {host}:{port}")
            self.server_host = host
            self.server_port = port
            self.connected = True
            self.running = True
            
            print(f"Connected to server at {host}:{port}")
            
            # Start receiving messages
            self.receive_thread = threading.Thread(target=self.receive_messages)
            self.receive_thread.daemon = True
            self.receive_thread.start()
            
            return True
            
        except socket.timeout:
            print(f"Connection timeout to {host}:{port}")
            return False
        except ConnectionRefusedError:
            print(f"Connection refused by {host}:{port} - server may not be running")
            return False
        except Exception as e:
            print(f"Failed to connect to server {host}:{port}: {e}")
            return False
    
    def receive_messages(self):
        """Receive messages from server"""
        while self.running and self.connected:
            try:
                data = self.socket.recv(4096)
                if not data:
                    break
                
                message = json.loads(data.decode('utf-8'))
                self.process_message(message)
                
            except Exception as e:
                if self.running:
                    print(f"Error receiving message: {e}")
                break
        
        # Disconnected
        self.connected = False
        print("Disconnected from server")
    
    def process_message(self, message):
        """Process incoming message from server"""
        msg_type = message.get('type')
        
        if msg_type == 'welcome':
            self.client_id = message.get('client_id')
            self.player_color = message.get('player_color')
            print(f"Received welcome! Client ID: {self.client_id}")
            
            if self.callbacks['welcome']:
                self.callbacks['welcome'](message)
        
        elif msg_type == 'player_joined':
            client_id = message.get('client_id')
            player_data = message.get('player_data')
            self.server_players[client_id] = player_data
            
            if self.callbacks['player_joined']:
                self.callbacks['player_joined'](message)
        
        elif msg_type == 'player_left':
            client_id = message.get('client_id')
            if client_id in self.server_players:
                del self.server_players[client_id]
            
            if self.callbacks['player_left']:
                self.callbacks['player_left'](message)
        
        elif msg_type == 'player_update':
            client_id = message.get('client_id')
            player_data = message.get('player_data')
            
            if client_id != self.client_id and client_id in self.server_players:
                self.server_players[client_id].update(player_data)
            
            if self.callbacks['player_update']:
                self.callbacks['player_update'](message)
        
        elif msg_type == 'game_state':
            self.game_state = message.get('game_state')
            self.server_info = message.get('server_info', {})
            
            # Update server players
            if 'players' in message:
                self.server_players = message['players']
            
            if self.callbacks['game_state']:
                self.callbacks['game_state'](message)
        
        elif msg_type == 'game_sync':
            # Real-time game state sync
            if self.callbacks['game_sync']:
                self.callbacks['game_sync'](message)
        
        elif msg_type == 'game_started':
            self.game_state = "playing"
            if self.callbacks['game_started']:
                self.callbacks['game_started'](message)
        
        elif msg_type == 'chat':
            if self.callbacks['chat']:
                self.callbacks['chat'](message)
        
        elif msg_type == 'server_full':
            print("Server is full!")
            if self.callbacks['server_full']:
                self.callbacks['server_full'](message)
        
        elif msg_type == 'error':
            print(f"Server error: {message.get('message')}")
            if self.callbacks['error']:
                self.callbacks['error'](message)
    
    def send_message(self, message):
        """Send message to server"""
        if self.connected and self.socket:
            try:
                # Convert message to simple dict without complex objects
                simple_message = {}
                for key, value in message.items():
                    if isinstance(value, (str, int, float, bool, list, dict, type(None))):
                        simple_message[key] = value
                    else:
                        simple_message[key] = str(value)
                
                data = json.dumps(simple_message).encode('utf-8')
                self.socket.send(data)
            except Exception as e:
                print(f"Error sending message: {e}")
                self.connected = False
    
    def update_player_data(self, **kwargs):
        """Update local player data and send to server"""
        self.local_player_data.update(kwargs)
        
        self.send_message({
            'type': 'update',
            'player_data': self.local_player_data
        })
    
    def send_position(self, pos):
        """Send position update"""
        self.local_player_data['pos'] = [int(pos[0]), int(pos[1])]
        self.send_message({
            'type': 'update',
            'player_data': {'pos': self.local_player_data['pos']}
        })
    
    def send_hp(self, hp, max_hp=None):
        """Send HP update"""
        self.local_player_data['hp'] = hp
        if max_hp:
            self.local_player_data['max_hp'] = max_hp
        
        self.send_message({
            'type': 'update',
            'player_data': {'hp': hp, 'max_hp': self.local_player_data['max_hp']}
        })
    
    def send_level_xp(self, level, xp):
        """Send level and XP update"""
        self.local_player_data['level'] = level
        self.local_player_data['xp'] = xp
        
        self.send_message({
            'type': 'update',
            'player_data': {'level': level, 'xp': xp}
        })
    
    def start_game(self):
        """Request to start the game"""
        self.send_message({'type': 'start_game'})
    
    def send_chat(self, message):
        """Send chat message"""
        self.send_message({
            'type': 'chat',
            'message': message
        })
    
    def disconnect(self):
        """Disconnect from server"""
        self.running = False
        self.connected = False
        
        if self.socket:
            try:
                self.socket.close()
            except:
                pass
        
        print("Disconnected from server")
    
    def set_callback(self, message_type: str, callback: Callable):
        """Set callback for specific message type"""
        if message_type in self.callbacks:
            self.callbacks[message_type] = callback
    
    def get_server_players(self) -> Dict[int, Dict]:
        """Get all players on server"""
        return self.server_players.copy()
    
    def get_player_count(self) -> int:
        """Get number of connected players"""
        return len(self.server_players) + (1 if self.client_id else 0)

class NetworkGameClient:
    """Extended client with game integration"""
    
    def __init__(self, game_instance):
        self.game = game_instance
        self.network_client = NetworkClient()
        self.is_host = False
        
        # Network players (remote players)
        self.network_players = {}
        
        # Set up callbacks
        self.setup_callbacks()
        
        # Sync rate
        self.last_send_time = 0
        self.send_interval = 1.0 / 30  # 30 FPS send rate
    
    def setup_callbacks(self):
        """Set up network message callbacks"""
        self.network_client.set_callback('welcome', self.on_welcome)
        self.network_client.set_callback('player_joined', self.on_player_joined)
        self.network_client.set_callback('player_left', self.on_player_left)
        self.network_client.set_callback('player_update', self.on_player_update)
        self.network_client.set_callback('game_sync', self.on_game_sync)
        self.network_client.set_callback('game_started', self.on_game_started)
    
    def connect_to_server(self, host='localhost', port=5555) -> bool:
        """Connect to game server"""
        return self.network_client.connect(host, port)
    
    def on_welcome(self, message):
        """Handle welcome message"""
        self.client_id = message.get('client_id')
        self.player_color = message.get('player_color')
        print(f"Connected as player {self.client_id}")
    
    def on_player_joined(self, message):
        """Handle player joining"""
        client_id = message.get('client_id')
        player_data = message.get('player_data')
        print(f"Player {client_id} joined the game")
    
    def on_player_left(self, message):
        """Handle player leaving"""
        client_id = message.get('client_id')
        if client_id in self.network_players:
            del self.network_players[client_id]
        print(f"Player {client_id} left the game")
    
    def on_player_update(self, message):
        """Handle player data update"""
        client_id = message.get('client_id')
        player_data = message.get('player_data')
        
        # Update network player
        if client_id != self.network_client.client_id:
            if client_id not in self.network_players:
                # Create new network player
                from multiplayer_manager import MultiplayerPlayer, PlayerConfig
                config = PlayerConfig(
                    player_id=client_id,
                    color=player_data.get('color', (255, 255, 255)),
                    controls={},
                    start_pos=player_data.get('pos', [400, 300])
                )
                self.network_players[client_id] = MultiplayerPlayer(config.start_pos, config)
            
            # Update player data
            network_player = self.network_players[client_id]
            if 'pos' in player_data:
                network_player.pos = pygame.Vector2(player_data['pos'])
                network_player.rect.center = network_player.pos
            if 'hp' in player_data:
                network_player.hp = player_data['hp']
            if 'max_hp' in player_data:
                network_player.max_hp = player_data['max_hp']
    
    def on_game_sync(self, message):
        """Handle real-time game state sync"""
        # Sync other players
        if 'players' in message:
            for player_data in message['players']:
                client_id = player_data.get('id')
                if client_id and client_id != self.network_client.client_id:
                    self.sync_network_player(client_id, player_data)
        
        # Could also sync enemies, projectiles, etc. here
        # For now, let each client handle their own enemies/projectiles
        # and only sync player positions
    
    def sync_network_player(self, client_id, player_data):
        """Sync network player state"""
        if client_id not in self.network_players:
            # Create network player if doesn't exist
            from multiplayer_manager import MultiplayerPlayer, PlayerConfig
            config = PlayerConfig(
                player_id=client_id,
                color=self.network_client.player_color or (255, 255, 255),
                controls={},
                start_pos=player_data.get('pos', [400, 300])
            )
            self.network_players[client_id] = MultiplayerPlayer(config.start_pos, config)
        
        # Update network player
        network_player = self.network_players[client_id]
        if 'pos' in player_data:
            # Smooth position updates
            target_pos = pygame.Vector2(player_data['pos'])
            if not hasattr(network_player, 'target_pos'):
                network_player.target_pos = target_pos
            else:
                network_player.target_pos = target_pos
            
            # Interpolate position
            if hasattr(network_player, 'target_pos'):
                network_player.pos = network_player.pos.lerp(network_player.target_pos, 0.3)
                network_player.rect.center = network_player.pos
        
        if 'hp' in player_data:
            network_player.hp = player_data['hp']
        if 'max_hp' in player_data:
            network_player.max_hp = player_data['max_hp']
    
    def on_game_started(self, message):
        """Handle game start"""
        self.game.game_state = "playing"
        print("Game started!")
    
    def update(self, dt):
        """Update network client"""
        if not self.network_client.connected:
            return
        
        current_time = time.time()
        
        # Send local player updates at intervals
        if current_time - self.last_send_time >= self.send_interval:
            if hasattr(self.game, 'player') and self.game.player:
                # Send position
                self.network_client.send_position([
                    int(self.game.player.pos.x),
                    int(self.game.player.pos.y)
                ])
                
                # Send HP if changed
                if hasattr(self.game.player, 'hp'):
                    self.network_client.send_hp(
                        self.game.player.hp,
                        self.game.player.max_hp
                    )
                
                # Send level/XP if changed
                if hasattr(self.game.player, 'level'):
                    self.network_client.send_level_xp(
                        self.game.player.level,
                        getattr(self.game.player, 'xp', 0)
                    )
            
            self.last_send_time = current_time
    
    def get_network_players(self):
        """Get all network players"""
        return list(self.network_players.values())
    
    def disconnect(self):
        """Disconnect from server"""
        self.network_client.disconnect()
        self.network_players.clear()
