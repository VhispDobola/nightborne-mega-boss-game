import pygame
import math
from projectile import Projectile, ProjectileType, Weapon
from sounds import play_sound
from powerups import PowerUpType

class Player(pygame.sprite.Sprite):
    def __init__(self, pos):
        super().__init__()
        
        # Visual setup
        self.original_image = pygame.Surface((40, 40), pygame.SRCALPHA)
        pygame.draw.polygon(self.original_image, (0, 200, 255), [(20,0),(40,40),(0,40)])
        self.image = self.original_image.copy()
        self.rect = self.image.get_rect(center=pos)
        self.pos = pygame.Vector2(pos)
        
        # Core stats
        self.max_hp = 100
        self.hp = self.max_hp
        self.speed = 280
        self.damage = 10
        self.fire_rate = 1.0  # shots per second
        self.projectile_speed = 650
        self.pickup_range = 80
        
        # Weapon system
        self.weapon_level = 1
        self.weapon = Weapon(ProjectileType.BASIC)
        self.piercing = False
        
        # Shooting system
        self.shoot_timer = 0
        self.is_shooting = False
        
        # Position history for enemy targeting
        self.position_history = []
        self.position_history_max = 10  # Store last 10 positions
        self.position_history_timer = 0
        self.position_history_interval = 0.1  # Record position every 0.1 seconds
        self.xp = 0
        self.level = 1
        self.xp_to_next_level = 50
        
        # Power-up system
        self.power_up_effects = {}  # {power_type: [duration, value]}
        self.base_speed = self.speed
        self.base_damage = self.damage
        self.base_fire_rate = self.fire_rate
        self.shield_active = False
        self.invincible = False
        
        # NEW: Active ability system
        self.active_abilities = []
        self.ability_cooldowns = {}  # {ability_type: cooldown_time}
        
        # NEW: Passive ability system
        self.passive_abilities = []
        
        # NEW: Defensive stats
        self.armor = 0
        self.evasion_chance = 0.0
        self.regeneration_rate = 0
        self.regen_timer = 0
        
        # NEW: Range multipliers
        self.projectile_range_multiplier = 1.0
        self.explosion_radius_multiplier = 1.0
        self.damage_radius_multiplier = 1.0
        
    def update_position_history(self, dt):
        """Update position history for enemy targeting"""
        self.position_history_timer += dt
        if self.position_history_timer >= self.position_history_interval:
            self.position_history_timer = 0
            # Add current position to history
            self.position_history.append(self.pos.copy())
            # Keep only recent positions
            if len(self.position_history) > self.position_history_max:
                self.position_history.pop(0)
    
    def get_previous_position(self, delay_seconds=0.5):
        """Get player's position from delay_seconds ago"""
        # Calculate how many positions back to go
        positions_back = int(delay_seconds / self.position_history_interval)
        positions_back = min(positions_back, len(self.position_history) - 1)
        
        if positions_back >= 0 and len(self.position_history) > positions_back:
            return self.position_history[-(positions_back + 1)]
        else:
            return self.pos  # Fallback to current position
    
    def update(self, dt):
        """Update player state"""
        # Update position history first
        self.update_position_history(dt)
        
        # Movement
        keys = pygame.key.get_pressed()
        move = pygame.Vector2(
            (keys[pygame.K_d] - keys[pygame.K_a]),
            (keys[pygame.K_s] - keys[pygame.K_w])
        )
        if move.length() > 0:
            move = move.normalize()
        
        self.pos += move * self.speed * dt
        self.rect.center = self.pos
        
        # Keep player on screen
        screen_rect = pygame.display.get_surface().get_rect()
        self.pos.x = max(screen_rect.left + 20, min(screen_rect.right - 20, self.pos.x))
        self.pos.y = max(screen_rect.top + 20, min(screen_rect.bottom - 20, self.pos.y))
        self.rect.center = self.pos
        
        # Update power-up effects
        self.update_power_ups(dt)
        
        # NEW: Update ability cooldowns
        self.update_ability_cooldowns(dt)
        
        # NEW: Update passive abilities
        self.update_passive_abilities(dt)
        
        # Face movement direction (or mouse if manual aim)
        if move.length() > 0:
            angle = math.degrees(math.atan2(-move.y, move.x))
        else:
            mouse_pos = pygame.mouse.get_pos()
            dx, dy = mouse_pos[0] - self.rect.centerx, mouse_pos[1] - self.rect.centery
            angle = math.degrees(math.atan2(-dy, dx))
        
        self.image = pygame.transform.rotate(self.original_image, angle)
        self.rect = self.image.get_rect(center=self.rect.center)
        
        # Update shoot timer
        # Note: Timer is handled in manual_shoot method now
    
    def manual_shoot(self, dt, projectile_group, mouse_pos):
        """Manual shooting with mouse hold and fire rate control"""
        fire_threshold = 1.0 / self.weapon.fire_rate
        if self.is_shooting:
            self.shoot_timer += dt
            
            if self.shoot_timer >= fire_threshold:
                self.shoot_timer = 0
                self.shoot_toward_mouse(projectile_group, mouse_pos)
                play_sound('shoot')
        else:
            # Reset timer when not shooting
            self.shoot_timer = 0
    
    def shoot_toward_mouse(self, projectile_group, mouse_pos):
        """Shoot projectiles toward mouse position using weapon system"""
        # Get powerup multipliers
        damage_mult = self.get_power_up_multiplier(PowerUpType.DAMAGE_BOOST)
        
        # Convert mouse_pos to Vector2 if needed
        if isinstance(mouse_pos, tuple):
            target_pos = pygame.Vector2(mouse_pos)
        else:
            target_pos = mouse_pos
        
        # Use weapon's unique projectile creation if it has abilities
        if hasattr(self.weapon, 'abilities') and self.weapon.abilities:
            # Calculate direction to mouse position
            direction = pygame.Vector2(target_pos) - pygame.Vector2(self.rect.center)
            if direction.length() > 0:
                direction = direction.normalize()
            else:
                direction = pygame.Vector2(1, 0)  # Default forward
            
            # Create unique projectile that represents all combined abilities
            projectile = self.weapon.create_unique_projectile(
                self.rect.center, direction,
                damage_multiplier=damage_mult * (1.0 + (self.weapon_level - 1) * 0.3),
                speed_multiplier=1.0,
                piercing=self.piercing
            )
            projectile.level = self.weapon_level
            
            # Apply powerup effects to unique projectile
            # Apply explosive shots powerup
            if PowerUpType.EXPLOSIVE_SHOTS in self.power_up_effects:
                projectile.projectile_type = ProjectileType.EXPLOSIVE
                projectile.explosion_radius = 50 + (self.weapon_level - 1) * 15
                projectile.create_visual()  # Recreate visual with new type
            
            # Apply multi-shot powerup
            if PowerUpType.MULTI_SHOT in self.power_up_effects:
                multishot_value = int(self.power_up_effects[PowerUpType.MULTI_SHOT][1])
                if multishot_value > 1:
                    # Create multishot projectiles instead of single projectile
                    base_angle = math.degrees(math.atan2(direction.y, direction.x))
                    multishot_projectiles = []
                    
                    for i in range(multishot_value):
                        angle_offset = (i - (multishot_value - 1) / 2) * 10  # 10 degree spread
                        spread_angle = base_angle + angle_offset
                        spread_dir = pygame.Vector2(math.cos(math.radians(spread_angle)), 
                                                   math.sin(math.radians(spread_angle)))
                        
                        # Create projectile with same properties as main projectile would have
                        extra_proj = self.weapon.create_unique_projectile(
                            self.rect.center, spread_dir,
                            damage_multiplier=damage_mult * (1.0 + (self.weapon_level - 1) * 0.3),
                            speed_multiplier=1.0,
                            piercing=self.piercing
                        )
                        extra_proj.level = self.weapon_level
                        
                        # Apply explosive shots to multishot projectiles too
                        if PowerUpType.EXPLOSIVE_SHOTS in self.power_up_effects:
                            extra_proj.projectile_type = ProjectileType.EXPLOSIVE
                            extra_proj.explosion_radius = 50 + (self.weapon_level - 1) * 15
                            extra_proj.create_visual()
                        
                        multishot_projectiles.append(extra_proj)
                    
                    # Add all multishot projectiles
                    for extra_proj in multishot_projectiles:
                        projectile_group.add(extra_proj)
                else:
                    # No multishot, just add the single projectile
                    projectile_group.add(projectile)
            else:
                # No multishot powerup, just add the single projectile
                projectile_group.add(projectile)
            
            # Track shot statistics (if game reference is available)
            if hasattr(self, 'game') and self.game:
                self.game.update_stats("shot_fired")
        else:
            # Use standard weapon creation for basic weapons
            projectiles = self.weapon.create_projectiles(
                self.rect.center, target_pos, 
                damage_multiplier=damage_mult * (1.0 + (self.weapon_level - 1) * 0.3),
                speed_multiplier=1.0,
                piercing=self.piercing
            )
            
            # Apply powerup effects to projectiles
            for projectile in projectiles:
                # Apply explosive shots powerup
                if PowerUpType.EXPLOSIVE_SHOTS in self.power_up_effects:
                    projectile.projectile_type = ProjectileType.EXPLOSIVE
                    projectile.explosion_radius = 50 + (self.weapon_level - 1) * 15
                    projectile.create_visual()  # Recreate visual with new type
                
                # Apply multi-shot powerup
                if PowerUpType.MULTI_SHOT in self.power_up_effects:
                    multishot_value = int(self.power_up_effects[PowerUpType.MULTI_SHOT][1])
                    if multishot_value > 1:
                        # Replace the single projectile with multishot spread
                        base_angle = math.degrees(math.atan2(projectile.direction.y, projectile.direction.x))
                        multishot_projectiles = []
                        
                        for i in range(multishot_value):
                            angle_offset = (i - (multishot_value - 1) / 2) * 10  # 10 degree spread
                            spread_angle = base_angle + angle_offset
                            spread_dir = pygame.Vector2(math.cos(math.radians(spread_angle)), 
                                                       math.sin(math.radians(spread_angle)))
                            
                            # Create projectile with same properties
                            extra_proj = Projectile(
                                projectile.pos, spread_dir,
                                projectile.damage, projectile.speed,
                                projectile.projectile_type, projectile.piercing, level=projectile.level
                            )
                            
                            # Apply explosive shots to multishot projectiles too
                            if PowerUpType.EXPLOSIVE_SHOTS in self.power_up_effects:
                                extra_proj.projectile_type = ProjectileType.EXPLOSIVE
                                extra_proj.explosion_radius = projectile.explosion_radius
                                extra_proj.create_visual()
                            
                            extra_proj.level = self.weapon_level
                            multishot_projectiles.append(extra_proj)
                        
                        # Add all multishot projectiles instead of the original
                        for extra_proj in multishot_projectiles:
                            projectile_group.add(extra_proj)
                        continue  # Skip adding the original projectile
                
                projectile.level = self.weapon_level
                projectile_group.add(projectile)
                
                # Track shot statistics (if game reference is available)
                if hasattr(self, 'game') and self.game:
                    self.game.update_stats("shot_fired")
    
    def add_xp(self, amount):
        """Add XP and check for level up"""
        self.xp += amount
    
    def check_level_up(self):
        """Check if player leveled up and handle level up"""
        if self.xp >= self.xp_to_next_level:
            self.level_up()
            return True
        return False
    
    def level_up(self):
        """Handle level up"""
        self.level += 1
        self.xp = 0
        self.xp_to_next_level = int(self.xp_to_next_level * 1.5)  # Increase XP requirement
        
        # Restore some health on level up
        heal_amount = int(self.max_hp * 0.3)
        self.hp = min(self.hp + heal_amount, self.max_hp)
    
    def take_damage(self, amount):
        """Take damage, considering power-up effects"""
        if self.invincible:
            return  # No damage when invincible
        
        if self.shield_active:
            amount = int(amount * 0.5)  # Shield reduces damage by 50%
        
        self.hp -= amount
        if self.hp < 0:
            self.hp = 0
    
    def add_power_up_effect(self, power_type, duration, value):
        """Add a power-up effect to the player"""
        self.power_up_effects[power_type] = [duration, value]
        self.apply_power_up_effects()
    
    def update_power_ups(self, dt):
        """Update all active power-up effects"""
        effects_to_remove = []
        
        for power_type, [duration, value] in self.power_up_effects.items():
            new_duration = duration - dt
            if new_duration <= 0:
                effects_to_remove.append(power_type)
            else:
                self.power_up_effects[power_type] = [new_duration, value]
        
        # Remove expired effects
        for power_type in effects_to_remove:
            del self.power_up_effects[power_type]
        
        # Reapply effects
        self.apply_power_up_effects()
    
    def update_pre_powerup_stats(self):
        """Update stored pre-powerup stats when player gets upgrades"""
        self._pre_powerup_stats = {
            'speed': self.speed,
            'damage': self.damage, 
            'fire_rate': self.fire_rate
        }
        # Reapply current power-ups to the new base stats
        self.apply_power_up_effects()
    
    def apply_power_up_effects(self):
        """Apply all active power-up effects to player stats as bonuses"""
        # Store current stats (with upgrades) before applying power-ups
        if not hasattr(self, '_pre_powerup_stats'):
            self._pre_powerup_stats = {
                'speed': self.speed,
                'damage': self.damage, 
                'fire_rate': self.fire_rate
            }
        
        # Reset to pre-powerup stats (preserving upgrade bonuses)
        self.speed = self._pre_powerup_stats['speed']
        self.damage = self._pre_powerup_stats['damage']
        self.fire_rate = self._pre_powerup_stats['fire_rate']
        self.shield_active = False
        self.invincible = False
        
        # Apply power-up bonuses as multipliers to upgrade-enhanced stats
        for power_type, [duration, value] in self.power_up_effects.items():
            if power_type == PowerUpType.SPEED_BOOST:
                self.speed = int(self._pre_powerup_stats['speed'] * value)
            elif power_type == PowerUpType.DAMAGE_BOOST:
                self.damage = int(self._pre_powerup_stats['damage'] * value)
            elif power_type == PowerUpType.RAPID_FIRE:
                self.fire_rate = self._pre_powerup_stats['fire_rate'] * value
            elif power_type == PowerUpType.SHIELD:
                self.shield_active = True
            elif power_type == PowerUpType.INVINCIBILITY:
                self.invincible = True
            elif power_type == PowerUpType.MULTI_SHOT:
                # This is handled in shooting logic
                pass
            elif power_type == PowerUpType.PIERCING:
                self.piercing = True
            elif power_type == PowerUpType.EXPLOSIVE_SHOTS:
                # This is handled in projectile creation
                pass
    
    def heal(self, amount):
        """Heal the player"""
        self.hp = min(self.hp + amount, self.max_hp)
    
    def get_power_up_multiplier(self, power_type):
        """Get the multiplier for a specific power-up type"""
        if power_type in self.power_up_effects:
            return self.power_up_effects[power_type][1]
        return 1.0
    
    # NEW: Active ability methods
    def update_ability_cooldowns(self, dt):
        """Update ability cooldowns"""
        abilities_to_remove = []
        for ability, cooldown in self.ability_cooldowns.items():
            new_cooldown = cooldown - dt
            if new_cooldown <= 0:
                abilities_to_remove.append(ability)
            else:
                self.ability_cooldowns[ability] = new_cooldown
        
        for ability in abilities_to_remove:
            del self.ability_cooldowns[ability]
    
    def can_use_ability(self, ability_type):
        """Check if ability can be used (not on cooldown)"""
        return ability_type not in self.ability_cooldowns
    
    def use_active_ability(self, ability_type, game):
        """Use an active ability"""
        if not self.can_use_ability(ability_type):
            return False
        
        if ability_type == 'blast_wave':
            self.blast_wave(game)
            self.ability_cooldowns[ability_type] = 10.0  # 10 second cooldown
        elif ability_type == 'time_slow':
            self.time_slow(game)
            self.ability_cooldowns[ability_type] = 15.0  # 15 second cooldown
        elif ability_type == 'shield_burst':
            self.shield_burst(game)
            self.ability_cooldowns[ability_type] = 12.0  # 12 second cooldown
        elif ability_type == 'teleport':
            self.teleport(game)
            self.ability_cooldowns[ability_type] = 8.0  # 8 second cooldown
        elif ability_type == 'meteor_strike':
            self.meteor_strike(game)
            self.ability_cooldowns[ability_type] = 20.0  # 20 second cooldown
        
        return True
    
    def blast_wave(self, game):
        """Create a blast wave that knocks back and damages enemies"""
        blast_radius = 200
        blast_damage = 50
        
        # Create visual effect
        game.particle_system.create_explosion(self.pos, (100, 200, 255), 30)
        
        # Damage and knock back enemies
        for enemy in game.enemies:
            distance = (enemy.pos - self.pos).length()
            if distance <= blast_radius:
                # Damage enemy
                enemy.take_damage(blast_damage)
                # Knock back
                if distance > 0:
                    knock_direction = (enemy.pos - self.pos).normalize()
                    enemy.pos += knock_direction * 100
    
    def time_slow(self, game):
        """Slow down time for enemies"""
        # This would need game-level implementation
        # For now, just create visual effect
        game.particle_system.create_explosion(self.pos, (200, 100, 255), 40)
    
    def shield_burst(self, game):
        """Create a protective shield burst that damages nearby enemies"""
        shield_radius = 150
        shield_damage = 30
        
        # Give temporary shield
        self.shield_active = True
        if hasattr(self, 'power_up_effects'):
            self.power_up_effects[PowerUpType.SHIELD] = [5.0, 1.0]  # 5 second shield
        
        # Damage nearby enemies
        for enemy in game.enemies:
            distance = (enemy.pos - self.pos).length()
            if distance <= shield_radius:
                enemy.take_damage(shield_damage)
        
        # Visual effect
        game.particle_system.create_explosion(self.pos, (0, 255, 200), 25)
    
    def teleport(self, game):
        """Teleport to mouse position"""
        mouse_pos = pygame.mouse.get_pos()
        target_pos = pygame.Vector2(mouse_pos)
        
        # Create teleport effect at old position
        game.particle_system.create_explosion(self.pos, (255, 255, 255), 20)
        
        # Move player
        self.pos = target_pos
        self.rect.center = self.pos
        
        # Create teleport effect at new position
        game.particle_system.create_explosion(self.pos, (255, 255, 255), 20)
    
    def meteor_strike(self, game):
        """Call down a meteor strike at mouse position with shadow and screen shake"""
        mouse_pos = pygame.mouse.get_pos()
        target_pos = pygame.Vector2(mouse_pos)
        
        # Create large shadow at impact location
        game.particle_system.create_meteor_shadow(target_pos, 80)
        
        # Add delay before impact for dramatic effect
        def delayed_impact():
            # Create massive meteor impact
            game.particle_system.create_meteor_impact(target_pos)
            
            # Massive screen shake
            game.screen_shake.shake(50, 2.0)
            
            # Damage enemies in large impact area
            for enemy in game.enemies:
                distance = (enemy.pos - target_pos).length()
                if distance <= 200:  # Larger radius
                    damage = 150  # Higher damage
                    enemy.take_damage(damage)
                    # Knockback effect
                    if distance > 0:
                        knockback_dir = (enemy.pos - target_pos).normalize()
                        enemy.pos += knockback_dir * 100
                        enemy.rect.center = enemy.pos
        
        # Schedule the delayed impact
        game.schedule_event(1.0, delayed_impact)  # 1 second delay
    
    # NEW: Passive ability methods
    def update_passive_abilities(self, dt):
        """Update passive ability effects"""
        # Regeneration
        if self.regeneration_rate > 0:
            self.regen_timer += dt
            if self.regen_timer >= 1.0:  # Regenerate every second
                self.regen_timer = 0
                self.heal(self.regeneration_rate)
        
        # Adrenaline rush
        if 'adrenaline' in self.passive_abilities:
            hp_percentage = self.hp / self.max_hp
            if hp_percentage <= self.adrenaline_threshold:
                # Apply speed bonus
                if hasattr(self, 'adrenaline_speed_bonus'):
                    self.speed = int(self._pre_powerup_stats['speed'] * self.adrenaline_speed_bonus)
    
    def apply_critical_hit(self, damage):
        """Apply critical hit chance to damage"""
        if 'critical' in self.passive_abilities:
            import random
            if random.random() < self.critical_chance:
                return int(damage * self.critical_multiplier)
        return damage
